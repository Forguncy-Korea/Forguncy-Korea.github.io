var FilePreviewer;
(function (FilePreviewer) {
    var Events = (function () {
        function Events(mode) {
            if (mode === void 0) { mode = 0; }
            this.mode = mode;
            this.handlers = {};
            this.dom0Events = [];
            this.dom2Events = [];
        }
        Events.prototype.addHandler = function (eventName, handler, force) {
            if (force === void 0) { force = false; }
            if (this.mode === 0 || force) {
                this.registEvent(eventName);
            }
            if (this.handlers[eventName]) {
                this.handlers[eventName].push(handler);
            }
            else {
                throw new Error("The event is not registed.");
            }
            return handler;
        };
        Events.prototype.removeHandler = function (eventName, handler) {
            var handlers = this.handlers[eventName];
            if (handlers && handlers.length > 0) {
                var index = handlers.indexOf(handler);
                if (index >= 0) {
                    handlers.splice(index, 1);
                }
            }
        };
        Events.prototype.registEvent = function (eventName) {
            if (!this.handlers[eventName]) {
                this.handlers[eventName] = [];
            }
        };
        Events.prototype.registEventDomLevel0 = function (eventTarget, eventName, domEventName) {
            var _this = this;
            if (!this.handlers[eventName]) {
                this.handlers[eventName] = [];
                if (domEventName && eventTarget) {
                    eventTarget[domEventName] = function (event) {
                        _this.raiseEvent(eventName, event);
                    };
                    this.dom0Events.push({
                        ui: eventTarget,
                        name: domEventName
                    });
                }
            }
        };
        Events.prototype.registEventDomLevel2 = function (eventTarget, eventName, domEventName, useCapture) {
            var _this = this;
            if (!this.handlers[eventName]) {
                this.handlers[eventName] = [];
                if (domEventName && eventTarget) {
                    var listener = function (event) {
                        _this.raiseEvent(eventName, event);
                    };
                    eventTarget.addEventListener(domEventName, listener, useCapture);
                    this.dom2Events.push({
                        ui: eventTarget,
                        name: domEventName,
                        listener: listener
                    });
                }
            }
        };
        Events.prototype.raiseEvent = function (eventName) {
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            if (this.handlers[eventName]) {
                this.handlers[eventName].forEach(function (element) {
                    element.apply(void 0, args);
                });
            }
        };
        Events.prototype.release = function () {
            this.handlers = {};
            this.dom0Events.forEach(function (event) {
                event.ui[event.name] = null;
            });
            this.dom2Events.forEach(function (event) {
                event.ui.removeEventListener(event.name, event.listener);
            });
        };
        return Events;
    }());
    FilePreviewer.Events = Events;
})(FilePreviewer || (FilePreviewer = {}));
