var JsonDataSource;
(function (JsonDataSource) {
    var Common = (function () {
        function Common() {
        }
        Common.IsEmpty = function (obj) {
            if (obj === null || obj === "" || obj === undefined) {
                return true;
            }
            return false;
        };
        Common.format = function (s) {
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            args = args.map(function (arg) { return Common.IsEmpty(arg) ? "" : arg; });
            if (args.length === 0) {
                return s;
            }
            else if (args.length === 1 && typeof args[0] === 'object') {
                var reg = /{([^{}]+)}/gm;
                return s.replace(reg, function (match, name) {
                    return args[0][name];
                });
            }
            else {
                var reg = /{(\d+)}/gm;
                return s.replace(reg, function (match, name) {
                    return args[~~name];
                });
            }
        };
        return Common;
    }());
    JsonDataSource.Common = Common;
})(JsonDataSource || (JsonDataSource = {}));
