var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var SelectionPanel;
(function (SelectionPanel_1) {
    var _a;
    var SelectionPanel = (function (_super) {
        __extends(SelectionPanel, _super);
        function SelectionPanel() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.model = new SelectionPanel_1.SPanelModel();
            _this.loopInvoker = new LoopInvoker();
            _this._value = null;
            _this._hasDestroyed = false;
            return _this;
        }
        SelectionPanel.prototype.createContent = function () {
            this.container = $("<div id=\"".concat(this.ID, "\"></div>"));
            return this.container;
        };
        SelectionPanel.prototype.getValueFromElement = function () {
            var _this = this;
            return this.model.selections.length === 0 ?
                null :
                this.model.selections
                    .map(function (v) { return v.Values[_this.getActualValueIndex()]; })
                    .join(this.metadata.ValueSeparater);
        };
        SelectionPanel.prototype.getActualValueIndex = function () {
            var columns = this.listView.getMergedColumnInfos();
            var count = columns.filter(function (v) {
                return v.ColumnType === Forguncy.ListviewColumnType.RowHeader ||
                    v.ColumnType === Forguncy.ListviewColumnType.SelectedColumn;
            }).length;
            return this.metadata.ValueColumnIndex + count - 1;
        };
        SelectionPanel.prototype.isEmpty = function (value) {
            return value === null || value === undefined || value === "";
        };
        SelectionPanel.prototype.setValueToElement = function (jelement, value) {
            if (value === this._value ||
                (this.isEmpty(this._value) && this.isEmpty(value))) {
                return;
            }
            this._value = value;
            var values = [];
            if (!this.isEmpty(value)) {
                values = typeof (value) === "string" ?
                    value.split(this.metadata.ValueSeparater) :
                    [value];
            }
            var actualValueIndex = this.getActualValueIndex();
            this.listView.selectRowsByValue(values, actualValueIndex);
        };
        SelectionPanel.prototype.onLoad = function () {
            this._dataModel = this.getDataModel();
            this.initializeProperties();
            this.refresh(false);
        };
        SelectionPanel.prototype.initializeProperties = function () {
            var _this = this;
            var metadata = this.CellElement.CellType;
            this.metadata = metadata;
            metadata.ValueSeparater = StringHelper.validate(metadata.ValueSeparater) ? this.getApplicationResource(metadata.ValueSeparater) : metadata.ValueSeparater;
            metadata.HeaderTemplate = StringHelper.validate(metadata.HeaderTemplate) ? this.getApplicationResource(metadata.HeaderTemplate) : "";
            metadata.HeaderTemplateForNoSelection = StringHelper.validate(metadata.HeaderTemplateForNoSelection) ? this.getApplicationResource(metadata.HeaderTemplateForNoSelection) : "";
            this.listView = ListViewHelper.getListView(this, metadata.ListViewName);
            ListViewSelectionChangedCapture.regist(this.listView, function () {
                _this.loopInvoker.invokeable = true;
            });
            this.presenter = PresenterFactory.create(this.model, metadata, this.listView);
            this.presenter.setRootStyle(this.container.parent());
            this.container.append(this.presenter.container);
            this.loopInvoker.start(function () {
                _this.refresh(true);
            });
        };
        SelectionPanel.prototype.refresh = function (shouldCommitValue) {
            var _this = this;
            window.requestAnimationFrame(function () {
                if (_this._hasDestroyed || _this.shouldCancelRefresh()) {
                    return;
                }
                var rowsData = _this.listView.getSelectedRowsData();
                RowDataHelper.initDisplayValues(rowsData);
                RowDataHelper.formatDateTimeColumnDisplayValues(_this.listView.getMergedColumnInfos(), rowsData);
                _this.model.modify(rowsData);
                if (shouldCommitValue) {
                    if (_this._dataModel !== _this.getDataModel()) {
                        _this._dataModel.setValue(_this.ID, { newValue: _this.getValueFromElement() }, 5);
                    }
                    else {
                        _this._value = _this.getValueFromElement();
                        if (_this.isEmpty(_this._value)) {
                            _this._value = null;
                        }
                        _this._dataModel.setValue(_this.ID, { newValue: _this._value }, 7);
                    }
                }
            });
        };
        SelectionPanel.prototype.shouldCancelRefresh = function () {
            var dataModelValue = this._dataModel.getValue(this.ID);
            if ((this.isEmpty(this._value) && this.isEmpty(dataModelValue)) ||
                this._value === dataModelValue) {
                return false;
            }
            else {
                return true;
            }
        };
        SelectionPanel.prototype.getDataModel = function () {
            return Forguncy.ForguncyData.pageInfo.dataModel.normalCellDataModel;
        };
        SelectionPanel.prototype.destroy = function () {
            this.loopInvoker.invokeable = false;
            this._hasDestroyed = true;
            this._dataModel = null;
            _super.prototype.destroy.call(this);
        };
        return SelectionPanel;
    }(Forguncy.Plugin.CellTypeBase));
    SelectionPanel_1.SelectionPanel = SelectionPanel;
    var ListViewSelectionChangedCapture = (function () {
        function ListViewSelectionChangedCapture() {
        }
        ListViewSelectionChangedCapture.regist = function (listView, notify) {
            listView.bind(Forguncy.ListViewEvents.Reloaded, function (arg1, arg2) {
                setTimeout(function () {
                    notify && notify();
                }, 0);
            });
            listView.bind(Forguncy.ListViewEvents.SelectedRowsChanged, function (arg1, arg2) {
                notify && notify();
            });
            listView.bind(Forguncy.ListViewEvents.ValueChanged, function (arg1, arg2) {
                notify && notify();
            });
        };
        return ListViewSelectionChangedCapture;
    }());
    var PresenterFactory = (function () {
        function PresenterFactory() {
        }
        PresenterFactory.create = function (model, metadata, listView) {
            var presenter = new SelectionPanel_1.SPanelPresenter(model);
            presenter.isShowTooltip = metadata.IsShowTooltip;
            var headerSearchValue = StringHelper.validate(metadata.HeaderSearchValue);
            presenter.getHeaderHandler = function () {
                var actualHeader = model.selections.length > 0 ? metadata.HeaderTemplate : metadata.HeaderTemplateForNoSelection;
                return actualHeader.replace(headerSearchValue, model.selections.length.toString());
            };
            presenter.getIsShowTooltipHandler = function () {
                return metadata.IsShowTooltip;
            };
            var columns = listView.getMergedColumnInfos();
            var count = columns.filter(function (v) { return v.ColumnType === Forguncy.ListviewColumnType.RowHeader || v.ColumnType === Forguncy.ListviewColumnType.SelectedColumn; }).length;
            presenter.getDisplayColumnIndexHandler = function () {
                return metadata.DisplayColumnIndex + count - 1;
            };
            presenter.removeHandler = function (rowData) {
                if (rowData.Query && Object.keys(rowData.Query).length > 0) {
                    listView.clearSelectedRowByQuery(rowData.Query);
                }
                else {
                    listView.clearSelectedRow(rowData.RowIndex);
                }
            };
            return presenter;
        };
        return PresenterFactory;
    }());
    var LoopInvoker = (function () {
        function LoopInvoker() {
            this.interval = 50;
        }
        LoopInvoker.prototype.start = function (func, invokeable) {
            var _this = this;
            if (invokeable === void 0) { invokeable = false; }
            this.invokeable = invokeable;
            setInterval(function () {
                if (_this.invokeable) {
                    _this.invokeable = false;
                    func && func();
                }
            }, this.interval);
        };
        return LoopInvoker;
    }());
    var StringHelper = (function () {
        function StringHelper() {
        }
        StringHelper.validate = function (str) {
            if (str === undefined || str === null) {
                return "";
            }
            return str;
        };
        return StringHelper;
    }());
    var ListViewHelper = (function () {
        function ListViewHelper() {
        }
        ListViewHelper.getListView = function (cellType, listViewName) {
            var pageID = cellType.getFormulaCalcContext().PageID;
            var pageInfo = Forguncy.Page.getSubPageInfoByPageID(pageID);
            return pageInfo ? pageInfo.getListView(listViewName) : Forguncy.Page.getListView(listViewName, false);
        };
        return ListViewHelper;
    }());
    var FormatterString = (_a = {},
        _a[Forguncy.ColumnDataType.Date] = "yyyy-MM-dd hh:mm:ss",
        _a[Forguncy.ColumnDataType.Time] = "hh:mm:ss",
        _a);
    var RowDataHelper = (function () {
        function RowDataHelper() {
        }
        RowDataHelper.initDisplayValues = function (rowsData) {
            if (rowsData) {
                rowsData.forEach(function (rowData) {
                    rowData.displayValues = __spreadArray([], rowData.Values, true);
                });
            }
        };
        RowDataHelper.formatDateTimeColumnDisplayValues = function (mergedColumnInfos, rowsData) {
            mergedColumnInfos.forEach(function (info, index) {
                var type = info.ColumnDataType;
                if (type === Forguncy.ColumnDataType.Date || type === Forguncy.ColumnDataType.Time) {
                    rowsData.forEach(function (rowData) {
                        var value = rowData.Values[index];
                        if (value) {
                            var date = Forguncy.ConvertOADateToDate(rowData.Values[index]);
                            rowData.displayValues[index] = DateTimeFormatter.format(date, FormatterString[type]);
                        }
                    });
                }
            });
        };
        return RowDataHelper;
    }());
    var DateTimeFormatter = (function () {
        function DateTimeFormatter() {
        }
        DateTimeFormatter.format = function (date, formatString) {
            var keys = {
                "M+": date.getMonth() + 1,
                "d+": date.getDate(),
                "h+": date.getHours(),
                "m+": date.getMinutes(),
                "s+": date.getSeconds(),
                "q+": Math.floor((date.getMonth() + 3) / 3),
                "S": date.getMilliseconds()
            };
            if (/(y+)/.test(formatString)) {
                formatString = formatString.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            for (var k in keys) {
                if (new RegExp("(" + k + ")").test(formatString)) {
                    formatString = formatString.replace(RegExp.$1, (RegExp.$1.length === 1) ? (keys[k]) : (("00" + keys[k]).substr(("" + keys[k]).length)));
                }
            }
            return formatString;
        };
        return DateTimeFormatter;
    }());
})(SelectionPanel || (SelectionPanel = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("SelectionPanel.SelectionPanel, SelectionPanel", SelectionPanel.SelectionPanel);
