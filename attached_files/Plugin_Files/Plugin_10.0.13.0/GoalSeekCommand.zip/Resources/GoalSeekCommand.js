var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var GoalSeekCommand;
(function (GoalSeekCommand_1) {
    var GoalSeekCommand = (function (_super) {
        __extends(GoalSeekCommand, _super);
        function GoalSeekCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        GoalSeekCommand.prototype.execute = function () {
            var commandSetting = this.CommandParam;
            var workbook = new GC.Spread.Sheets.Workbook("GoalSeekCommand", { sheetCount: 1 });
            var worksheet = workbook.getActiveSheet();
            if (window["method_548D420FE41E42B7B9E3C32B3860D146"]) {
                worksheet.setValue = window["method_548D420FE41E42B7B9E3C32B3860D146"];
            }
            var formula = commandSetting.Formula;
            if (formula.startsWith('=') === false) {
                formula = "=" + formula;
            }
            var paramsCount = commandSetting.Params.length;
            var replacementMap = new Map();
            for (var rowIndex = 0; rowIndex < paramsCount; rowIndex++) {
                var param = commandSetting.Params[rowIndex];
                worksheet.setValue(rowIndex, 0, this.evaluateFormula(param.ParameterValue));
                replacementMap.set(param.ParameterName, rowIndex);
            }
            replacementMap.set(commandSetting.Variable, paramsCount);
            formula = this.replaceParameterWithFormula(formula, worksheet, replacementMap);
            worksheet.setFormula(paramsCount + 1, 0, formula);
            var goalValue = this.evaluateFormula(commandSetting.GoalValue);
            GC.Spread.Sheets.CalcEngine.goalSeek(worksheet, paramsCount, 0, worksheet, paramsCount + 1, 0, goalValue);
            var variableValue = worksheet.getValue(paramsCount, 0);
            Forguncy.CommandHelper.setVariableValue(commandSetting.VariableValueTo, variableValue);
        };
        GoalSeekCommand.prototype.replaceParameterWithFormula = function (formula, sheet, replacementMap) {
            var expression = GC.Spread.Sheets.CalcEngine.formulaToExpression(sheet, formula, 0, 0);
            var visitor = new ExpressionVisitor(sheet, replacementMap);
            var newExpr = visitor.visit(expression, 0, 0);
            var newFormula = GC.Spread.Sheets.CalcEngine.expressionToFormula(sheet, newExpr);
            return newFormula;
        };
        return GoalSeekCommand;
    }(Forguncy.Plugin.CommandBase));
    GoalSeekCommand_1.GoalSeekCommand = GoalSeekCommand;
    var ExpressionVisitor = (function () {
        function ExpressionVisitor(sheet, replacementMap) {
            this._worksheet = sheet;
            this._replacementMap = replacementMap;
        }
        ExpressionVisitor.prototype.visit = function (expr, baseRow, baseCol) {
            var expressionType = GC.Spread.CalcEngine.ExpressionType;
            switch (expr.type) {
                case expressionType.function:
                    return this.visitFunctionExpression(expr, baseRow, baseCol);
                case expressionType.name:
                    return this.visitNameExpression(expr, baseRow, baseCol);
                case expressionType.operator:
                    return this.visitOperatorExpression(expr, baseRow, baseCol);
                case expressionType.parentheses:
                    return this.visitParenthesesExpression(expr, baseRow, baseCol);
                default:
                    return expr;
            }
        };
        ExpressionVisitor.prototype.visitFunctionExpression = function (expr, baseRow, baseCol) {
            var changed = false;
            var args = [];
            for (var i = 0; i < expr.arguments.length; i++) {
                var oldArg = expr.arguments[i];
                args[i] = this.visit(oldArg, baseRow, baseCol);
                if (oldArg !== args[i]) {
                    changed = true;
                }
            }
            if (changed) {
                var newExpr = (new GC.Spread.CalcEngine.Expression(GC.Spread.CalcEngine.ExpressionType.function));
                newExpr.arguments = args;
                if (expr instanceof GC.Spread.CalcEngine.Expression) {
                    newExpr.function = expr.function;
                    newExpr.functionName = expr.functionName;
                }
                else {
                    newExpr.function = expr.name && expr;
                    newExpr.functionName = expr.name || expr;
                }
                return newExpr;
            }
            else {
                return expr;
            }
        };
        ExpressionVisitor.prototype.visitNameExpression = function (expr, baseRow, baseCol) {
            var oldName = expr.value;
            if (this._replacementMap.has(oldName) === true) {
                var rowIndex = this._replacementMap.get(oldName);
                var newExpr = new GC.Spread.CalcEngine.Expression(GC.Spread.CalcEngine.ExpressionType.name);
                newExpr.value = "A" + (rowIndex + 1);
                return newExpr;
            }
            return expr;
        };
        ExpressionVisitor.prototype.visitOperatorExpression = function (expr, baseRow, baseCol) {
            var newValue = this.visit(expr.value, baseRow, baseCol);
            var newValue2 = this.visit(expr.value2, baseRow, baseCol);
            if (newValue !== expr.value || newValue2 !== expr.value2) {
                var newExpr = (new GC.Spread.CalcEngine.Expression(GC.Spread.CalcEngine.ExpressionType.operator));
                newExpr.operatorType = expr.operatorType;
                newExpr.value = newValue;
                newExpr.value2 = newValue2;
                return newExpr;
            }
            else {
                return expr;
            }
        };
        ExpressionVisitor.prototype.visitParenthesesExpression = function (expr, baseRow, baseCol) {
            var newValue = this.visit(expr.value, baseRow, baseCol);
            if (newValue !== expr.value) {
                var newExpr = (new GC.Spread.CalcEngine.Expression(GC.Spread.CalcEngine.ExpressionType.parentheses));
                newExpr.value = newValue;
                return newExpr;
            }
            else {
                return expr;
            }
        };
        return ExpressionVisitor;
    }());
    GoalSeekCommand_1.ExpressionVisitor = ExpressionVisitor;
})(GoalSeekCommand || (GoalSeekCommand = {}));
Forguncy.Plugin.CommandFactory.registerCommand("GoalSeekCommand.GoalSeekCommand, GoalSeekCommand", GoalSeekCommand.GoalSeekCommand);
