var PassListviewDataCommand;
(function (PassListviewDataCommand) {
    var RSHelper = (function () {
        function RSHelper() {
        }
        RSHelper.getRS = function () {
            return Forguncy.Plugin.LocalizationResourceHelper.getPluginResource("2588589e-5517-49f1-a400-42529890f835");
        };
        return RSHelper;
    }());
    PassListviewDataCommand.RSHelper = RSHelper;
})(PassListviewDataCommand || (PassListviewDataCommand = {}));
