var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var PDACommand;
(function (PDACommand) {
    var PdaScanCommand = (function (_super) {
        __extends(PdaScanCommand, _super);
        function PdaScanCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        PdaScanCommand.prototype.execute = function () {
            if (!window.ReactNativeWebView) {
                alert(this.getResourceString("ReactNativeError"));
                return;
            }
            var params = this.CommandParam;
            var scanType = params.ScanType;
            var targetCell = params.TargetCell ? this.getCellLocation(params.TargetCell) : null;
            if (targetCell === null && scanType !== "Stop") {
                alert(this.getResourceString("CellLocationEmptyError"));
                return;
            }
            if ((params.BroadcastActionName !== undefined && params.BroadcastKeyName === undefined) ||
                (params.BroadcastActionName === undefined && params.BroadcastKeyName !== undefined)) {
                alert(this.getResourceString("BroadcastError"));
                return;
            }
            this.currentPageName = Forguncy.Page.getPageName();
            var cellLocation = targetCell ? JSON.stringify(targetCell) : "";
            var js = "\n                try {\n                    const command = new PDACommand.PdaScanCommand();\n                    command.currentPageName = '".concat(this.currentPageName, "';\n                    command.setScanResult('").concat(cellLocation, "', @result);\n                } catch(e) {\n                    console.log(e)\n                }\n                true;\n            ");
            var scanInfo = {
                type: "plugin",
                data: {
                    scanType: scanType,
                    cellLocation: cellLocation,
                    modalMode: false,
                    script: js,
                    broadcastActionName: params.BroadcastActionName,
                    broadcastKeyName: params.BroadcastKeyName,
                    guid: "850b33ec-2fab-4c4f-9de9-47ef0cae0bbe"
                }
            };
            window.ReactNativeWebView.postMessage(JSON.stringify(scanInfo));
        };
        PdaScanCommand.prototype.setScanResult = function (cellInfo, barCode) {
            if (this.currentPageName !== Forguncy.Page.getPageName()) {
                return;
            }
            var cellLocation = JSON.parse(cellInfo);
            document.activeElement.blur();
            Forguncy.Page.getCellByLocation(cellLocation).setValue(barCode);
        };
        PdaScanCommand.prototype.getResourceString = function (key) {
            return this.getPluginResource(key);
        };
        return PdaScanCommand;
    }(Forguncy.Plugin.CommandBase));
    PDACommand.PdaScanCommand = PdaScanCommand;
})(PDACommand || (PDACommand = {}));
Forguncy.Plugin.CommandFactory.registerCommand("PDACommand.PdaScanCommand, PDACommand", PDACommand.PdaScanCommand);
