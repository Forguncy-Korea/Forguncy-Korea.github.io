var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Forguncy;
(function (Forguncy) {
    var TinyRichEditor;
    (function (TinyRichEditor_1) {
        var LanguageStr;
        (function (LanguageStr) {
            LanguageStr["zh_CN"] = "zh_CN";
            LanguageStr["ja_JP"] = "ja";
            LanguageStr["ko_KR"] = "ko_KR";
        })(LanguageStr || (LanguageStr = {}));
        var lang = Forguncy.RS.Culture;
        if (Forguncy.RS.Culture === "cn") {
            lang = LanguageStr.zh_CN;
        }
        else if (Forguncy.RS.Culture === "kr") {
            lang = LanguageStr.ko_KR;
        }
        else if (Forguncy.RS.Culture === "ja") {
            lang = LanguageStr.ja_JP;
        }
        window.Forguncy["TinyRichEditorCustomParams"] = window.Forguncy["TinyRichEditorCustomParams"] || [];
        var TinyRichEditor = (function (_super) {
            __extends(TinyRichEditor, _super);
            function TinyRichEditor() {
                var _this = _super !== null && _super.apply(this, arguments) || this;
                _this._initValue = "";
                _this._preValue = "";
                return _this;
            }
            Object.defineProperty(TinyRichEditor.prototype, "cellTypeMetaData", {
                get: function () {
                    return this.CellElement.CellType;
                },
                enumerable: false,
                configurable: true
            });
            TinyRichEditor.prototype.createContent = function () {
                var container = $("<div class=\"fgc-tinyricheditor\" style=\"height:100%\"></div>");
                var hiddenDom = $("<div style=\"height:100%;\"></div>");
                this._tinyRichEditorContainer = hiddenDom;
                container.append(hiddenDom);
                return container;
            };
            TinyRichEditor.prototype.onPageLoaded = function () {
                return __awaiter(this, void 0, void 0, function () {
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                tinymce.addI18n(lang, Forguncy.Plugin.LocalizationResourceHelper.getPluginResource("b1356c5e-670a-499a-b96e-4d5193e3e647"));
                                return [4, this.initOptions(this._tinyRichEditorContainer)[0]];
                            case 1:
                                _a.sent();
                                this._tinyRichEditorContainer.next().css("height", "100%");
                                return [2];
                        }
                    });
                });
            };
            TinyRichEditor.prototype.setTabIndexToElement = function (tabIndex) {
                if (tabIndex === 0) {
                    this._tinyRichEditorContainer.removeAttr("tabindex");
                }
                else {
                    this._tinyRichEditorContainer.attr("tabindex", tabIndex);
                }
            };
            TinyRichEditor.prototype.replaceText = function (text) {
                if (!text) {
                    return "";
                }
                if (typeof text !== 'string') {
                    text = text.toString();
                }
                if (this.CellElement.CellType.StrictSecurityMode) {
                    text = DOMPurify.sanitize(text);
                    this.outputHtmlContentRemoved();
                }
                else {
                    text = text.replace(/<[\r|\n|\s]*script[\r|\n|\s]*/gi, "&lt;script");
                }
                var closingTagReg = /<[a-z]+\d*>.*<\/[a-z]+\d*>/gim;
                var autoClosingTagReg = /<[a-z]+\d*\/>/gim;
                if (closingTagReg.test(text) || autoClosingTagReg.test(text)) {
                    return text;
                }
                return text.replace(new RegExp(/\r\n/, "g"), '<br/>').replace(new RegExp(/\r/, "g"), '<br/>').replace(new RegExp(/\n/, "g"), '<br/>');
            };
            TinyRichEditor.prototype.getOptionsByCellName = function (name) {
                var _a, _b;
                var customParams = window.Forguncy["TinyRichEditorCustomParams"];
                return (_b = (_a = customParams.find(function (item) { return item.name === name; })) === null || _a === void 0 ? void 0 : _a.options) !== null && _b !== void 0 ? _b : {};
            };
            TinyRichEditor.prototype.getMergeOptions = function (defaultOptions, options) {
                var result = __assign({}, defaultOptions);
                if (Object.keys(options).length) {
                    $.each(options, function (key, val) {
                        if (TinyRichEditor.MERGE_WHITELIST.includes(key)) {
                            if (typeof val === "function") {
                                var defaultFn_1 = result[key];
                                result[key] = function () {
                                    var args = [];
                                    for (var _i = 0; _i < arguments.length; _i++) {
                                        args[_i] = arguments[_i];
                                    }
                                    val.apply(void 0, args);
                                    defaultFn_1.apply(void 0, args);
                                };
                            }
                        }
                        else {
                            result[key] = val;
                        }
                    });
                }
                return result;
            };
            TinyRichEditor.prototype.initOptions = function (container) {
                var defaultOptions = this.getDefaultOptions();
                var options = this.getOptionsByCellName(this._tinyRichEditorContainer.closest("[fgcname]").attr("fgcname"));
                var mergeOptions = this.getMergeOptions(defaultOptions, options);
                return tinymce.init(__assign({ target: container[0] }, mergeOptions));
            };
            TinyRichEditor.prototype.getDefaultMenuBarConfig = function () {
                if (!this.cellTypeMetaData.ShowMenuBars) {
                    return false;
                }
                return TinyRichEditor.DEFAULT_MENUBARS;
            };
            TinyRichEditor.prototype.getDefaultToolBarConfig = function () {
                if (!this.cellTypeMetaData.ShowToolBars) {
                    return false;
                }
                return TinyRichEditor.DEFAULT_TOOLBARs;
            };
            TinyRichEditor.prototype.getDefaultPluginConfig = function () {
                return TinyRichEditor.DEFAULT_PLUGINS.split(",").map(function (item) { return item.trim(); });
            };
            TinyRichEditor.prototype.getRemovedMenuitems = function () {
                if (!this.cellTypeMetaData.ShowMenuBars) {
                    return "";
                }
                return TinyRichEditor.DEFAULT_MENUBARS_Remove;
            };
            TinyRichEditor.prototype.getExternalPluginConfig = function () {
                if (!this.isDesignerPreview && this.isAutoFitHeight()) {
                    return ['autoresize'];
                }
                return [''];
            };
            TinyRichEditor.prototype.getDefaultOptions = function () {
                var _this = this;
                var _a;
                var WaterMark = this.cellTypeMetaData.WaterMark;
                WaterMark = (_a = this.getApplicationResource(WaterMark !== null && WaterMark !== void 0 ? WaterMark : "")) !== null && _a !== void 0 ? _a : "";
                return {
                    language: lang,
                    placeholder: WaterMark,
                    content_css: ["default", "".concat(Forguncy.Helper.SpecialPath.getPluginRootPath("b1356c5e-670a-499a-b96e-4d5193e3e647"), "Resources/TinyRichEditorEditArea.css")],
                    content_style: "body{ font-family:".concat(Forguncy.LocaleFonts.default, ";}"),
                    menubar: this.getDefaultMenuBarConfig(),
                    toolbar: this.getDefaultToolBarConfig(),
                    plugins: this.getDefaultPluginConfig().concat(this.getExternalPluginConfig()),
                    removed_menuitems: this.getRemovedMenuitems(),
                    images_file_types: TinyRichEditor.DEFAULT_IMAGE_FILE_TYPES,
                    file_picker_types: 'image',
                    file_picker_callback: function (cb, value, meta) {
                        if (meta.filetype == 'image') {
                            var input_1 = document.createElement('input');
                            input_1.setAttribute('type', 'file');
                            input_1.setAttribute('accept', 'image/*');
                            input_1.addEventListener('change', function (e) {
                                var file = e.target.files[0];
                                var reader = new FileReader();
                                reader.addEventListener('load', function () {
                                    var id = 'blobid' + (new Date()).getTime();
                                    var blobCache = tinymce.activeEditor.editorUpload.blobCache;
                                    var base64 = reader.result.split(',')[1];
                                    var blobInfo = blobCache.create(id, file, base64);
                                    blobCache.add(blobInfo);
                                    cb(blobInfo.blobUri(), { title: file.name });
                                    input_1.parentNode.removeChild(input_1);
                                });
                                reader.readAsDataURL(file);
                            });
                            input_1.click();
                        }
                    },
                    init_instance_callback: function (editor) {
                        _this._tinymceEditor = editor;
                        _this.updateEditorMode();
                        var text = _this._initValue;
                        if (_this.isDesignerPreview && _this.isEmpty(text)) {
                            var helpTextForPage = _this.designerPreviewCustomArgs[0];
                            if (helpTextForPage) {
                                text = helpTextForPage;
                            }
                        }
                        editor.setContent(_this.replaceText(text));
                        _this._preValue = editor.getContent();
                        _this.setTinyEditorBackgroundColor(_this._tinymceEditor, _this.CellElement.StyleInfo.Background);
                        if (!_this.isDesignerPreview && !_this.isAutoFitHeight()) {
                            $(".fgc-tinyricheditor .tox-tinymce")[0].style.height = 'inherit';
                        }
                    },
                    setup: function (editor) {
                        editor.on("blur", function () {
                            _this._tinyRichEditorContainer.parent().trigger("focusout");
                            if (!_this.isReadOnly()) {
                                _this.validate();
                            }
                            if (_this._preValue !== editor.getContent()) {
                                _this.executeCustomCommandObject(_this.cellTypeMetaData.EditCommand, null);
                            }
                            _this.commitValue();
                            _this._preValue = editor.getContent();
                        });
                        editor.on('input', function () {
                            _this.hideValidateTooltip();
                        });
                        editor.on("focus", function () {
                            _this._tinyRichEditorContainer.parent().trigger("focusin");
                        });
                    },
                    font_family_formats: "".concat(Forguncy.LocaleFonts.default, ";") + TinyRichEditor.DEFAULT_FONTS,
                    paste_data_images: true,
                    contextmenu: false,
                    promotion: false,
                    branding: false,
                    resize: false,
                    statusbar: false,
                    toolbar_mode: "sliding",
                    autoresize_bottom_margin: 0,
                    mobile: {
                        menubar: this.getDefaultMenuBarConfig(),
                        toolbar_mode: "sliding",
                    },
                };
            };
            TinyRichEditor.prototype.setTinyEditorBackgroundColor = function (tinymce, color) {
                if (!tinymce) {
                    return;
                }
                tinymce.dom.setStyle(tinymce.dom.select(".mce-content-body"), 'background-color', Forguncy.ConvertToCssColor(color));
            };
            TinyRichEditor.prototype.setBackColor = function (color) {
                _super.prototype.setBackColor.call(this, color);
                this.setTinyEditorBackgroundColor(this._tinymceEditor, color);
            };
            TinyRichEditor.prototype.setFocus = function () {
                if (!this._tinymceEditor || this.isReadOnly()) {
                    return;
                }
                this._tinymceEditor.focus();
            };
            TinyRichEditor.prototype.getDefaultValue = function () {
                var _a;
                var val = this.evaluateFormula((_a = this.cellTypeMetaData.DefaultValue) === null || _a === void 0 ? void 0 : _a.toString());
                if (this.isEmpty(val)) {
                    return null;
                }
                return {
                    Value: val
                };
            };
            TinyRichEditor.prototype.getValueFromElement = function () {
                if (!this._tinymceEditor) {
                    return this._initValue;
                }
                if (this.CellElement.CellType.StrictSecurityMode) {
                    var safeHtml = DOMPurify.sanitize(this._tinymceEditor.getContent());
                    this.outputHtmlContentRemoved();
                    return safeHtml;
                }
                else {
                    return this._tinymceEditor.getContent();
                }
            };
            TinyRichEditor.prototype.setValueToElement = function (_, value) {
                if (!this._tinymceEditor) {
                    this._initValue = value;
                    return;
                }
                this._tinymceEditor.setContent(this.replaceText(value));
            };
            TinyRichEditor.prototype.outputHtmlContentRemoved = function () {
                var _a;
                if (!Forguncy.StaticData.IsDebugMode) {
                    return;
                }
                if (DOMPurify.removed && DOMPurify.removed.length > 0) {
                    var tips = (_a = {},
                        _a["en"] = "Removed potentially harmful content.",
                        _a["cn"] = "移除了可能有害的内容。",
                        _a["ja"] = "有害かもしれない内容を削除しました。",
                        _a["kr"] = "유해할 수 있는 내용을 제거했습니다.",
                        _a);
                    var locationStr = Forguncy.FormulaHelper.getCellLogLocationString(this.ID, this.Name, this.runTimePageName);
                    console.warn(tips[Forguncy.RS.Culture], locationStr, DOMPurify.removed);
                }
            };
            TinyRichEditor.prototype.isEmpty = function (obj) {
                if (obj === null || obj === '' || obj === undefined) {
                    return true;
                }
                return false;
            };
            TinyRichEditor.prototype.disable = function () {
                _super.prototype.disable.call(this);
                this.updateEditorMode();
            };
            TinyRichEditor.prototype.enable = function () {
                _super.prototype.enable.call(this);
                this.updateEditorMode();
            };
            TinyRichEditor.prototype.setReadOnly = function (value) {
                _super.prototype.setReadOnly.call(this, value);
                this.updateEditorMode();
            };
            TinyRichEditor.prototype.updateEditorMode = function () {
                if (!this._tinymceEditor) {
                    return;
                }
                var mode = (this.isDisabled() || this.isReadOnly()) ? 'readonly' : 'design';
                this._tinymceEditor.mode.set(mode);
            };
            TinyRichEditor.prototype.destroy = function () {
                if (this._tinymceEditor) {
                    this._tinymceEditor.destroy();
                    this._tinymceEditor = null;
                }
            };
            TinyRichEditor.DEFAULT_MENUBARS = "file edit view insert format tools table help";
            TinyRichEditor.DEFAULT_MENUBARS_Remove = "visualaid";
            TinyRichEditor.DEFAULT_TOOLBARs = " undo redo | blocks fontfamily fontsize |\n            bold italic forecolor backcolor | alignleft aligncenter alignright alignjustify | \n            bullist numlist outdent indent | removeformat | image";
            TinyRichEditor.DEFAULT_PLUGINS = "advlist,autolink,lists,link,\n        image,charmap,preview,anchor,searchreplace,visualblocks,\n        code,fullscreen,insertdatetime,media,table,help,wordcount";
            TinyRichEditor.DEFAULT_IMAGE_FILE_TYPES = "jpeg,jpg,jpe,jfi,jif,jfif,png,gif,bmp,webp,svg";
            TinyRichEditor.MERGE_WHITELIST = ["setup"];
            TinyRichEditor.DEFAULT_FONTS = "Andale Mono=andale mono,times; Arial=arial,helvetica,sans-serif; Arial Black=arial black,avant garde; \n        Book Antiqua=book antiqua,palatino; Comic Sans MS=comic sans ms,sans-serif; Courier New=courier new,courier; Georgia=georgia,palatino; Helvetica=helvetica; Impact=impact,chicago;\n        Tahoma=tahoma,arial,helvetica,sans-serif; Terminal=terminal,monaco; Times New Roman=times new roman,times; Trebuchet MS=trebuchet ms,geneva; Verdana=verdana,geneva; Webdings=webdings; Wingdings=wingdings";
            return TinyRichEditor;
        }(Forguncy.Plugin.CellTypeBase));
        TinyRichEditor_1.TinyRichEditor = TinyRichEditor;
    })(TinyRichEditor = Forguncy.TinyRichEditor || (Forguncy.TinyRichEditor = {}));
})(Forguncy || (Forguncy = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("TinyRichEditor.TinyRichEditorCellType, TinyRichEditor", Forguncy.TinyRichEditor.TinyRichEditor);
