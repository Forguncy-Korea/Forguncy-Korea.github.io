﻿/// <reference path="../Declarations/forguncy.d.ts" />
/// <reference path="../Declarations/forguncy.Plugin.d.ts" />

const JSON_DATA_SOURCE_NOT_INITED = "JSON_DATA_SOURCE_NOT_INITED";
class EchartsCustomCellTypeCellType extends Forguncy.Plugin.CellTypeBase {

    baiduMapInited = false;
    _resizeObserver = undefined;
    pageLoadInfo = undefined;
    JSONNotLoadedConId = ''
    config = {}
    dataDic = {};
    JSONDic = {};
    IconDic = {};
    JSONNotLoadedDic = {};

    echartsOption = undefined;

    echartsInst = undefined;
    datInst = undefined;

    timeoutMap = {};
    intervalMap = {};
    eventHandleAttached = false;
    async onPageLoaded(info, reloadKeepJSONData) {
        this.pageLoadInfo = info;
        const { DataSources, Config, JSONDataSources, BaiduMapAK } = this.CellElement.CellType;

        if (BaiduMapAK) {
            await this.initBaiduMap(BaiduMapAK);
        } else {
            await this.pageLoadedStep2(Config, DataSources, JSONDataSources, reloadKeepJSONData);
        }
    }

    async initBaiduMap(BaiduMapAK) {
        return new Promise((resolve) => {
            if (!this.baiduMapInited) {
                var script = document.createElement("script");
                const scriptId = this.ID + "_baiduMap";
                script.id = scriptId;
                script.src = `https://api.map.baidu.com/api?v=3.0&ak=${BaiduMapAK}&callback=${scriptId}_initialize`;
                window[scriptId + "_initialize"] = async () => {
                    await this.FGC_Bmap_initialize();
                    if (this.isDesignerPreview) {
                        // 百度地图初始化完成后，图一直在变，不能直接进行截图，但是现在又找不到一个合适的时机告诉C#端已经渲染完成，所以现在先延迟2秒，解决一部分问题 @Edric.Li
                        setTimeout(resolve, 2000);
                    } else {
                        resolve();
                    }
                };
                document.body.appendChild(script);
            }
        });
    }

    FGC_Bmap_initialize = async () => {
        this.baiduMapInited = true;
        const { DataSources, Config, JSONDataSources } = this.CellElement.CellType;
        await this.pageLoadedStep2(Config, DataSources, JSONDataSources, undefined);
    }
    async pageLoadedStep2(Config, DataSources, JSONDataSources, reloadKeepJSONData) {
        if (Config) {
            this.config = JSON.parse(Config);
        }
        let datas = [];

        if (this.isDesignerPreview) {
            const [dataSources] = this.designerPreviewCustomArgs;
            for (const key in dataSources) {
                datas.push({ name: key, data: dataSources[key] });
            }
        } else {
            datas = await Promise.all((DataSources || []).map(item => this.fetchDataSourceValue(item.Name, item.BindingTableOptions)));
        }
        if (reloadKeepJSONData !== undefined) {
            if (!reloadKeepJSONData) {
                this.JSONDic = {};
            }
        }
        const _jsonDataSouce = (JSONDataSources || []);
        this.fillIconDic();
        this.setDatas(datas);
        this.injectMockJSONDataWhenPreview(_jsonDataSouce);
        this.initEchartsContainer();
        await this.computeGraphData();
    }

    injectMockJSONDataWhenPreview(_jsonDataSouce) {
        if (this.isDesignerPreview) {
            this.batchSetDataSource(_jsonDataSouce);
        }
    }
    fillIconDic() {
        const raw = this.CellElement.CellType.ImageDataSource || [];
        raw.forEach(v => {
            const image = v.Image;
            if (image && image.Name) {
                let src = "";
                if (image.BuiltIn) {
                    // 构建内建图标URL
                    src = Forguncy.Helper.SpecialPath.getBuiltInImageFolderPath() + image.Name;
                }
                else {
                    // 构建用户上传图片URL
                    src = Forguncy.Helper.SpecialPath.getImageEditorUploadImageFolderPath() + encodeURIComponent(image.Name);
                }
                this.IconDic[v.Name] = src;
            }
        });
    }
    firstRenderd = false;

    initEchartsContainer = () => {
        this.firstRenderd = false;
        this.JSONNotLoadedConId = this.ID + 'JSONNotLoadedCon';
        const con = this.getContainer();
        const old = con.find(`#${this.echartsId}`);
        if (old.length === 0) {
            const div = $(`<div id="${this.echartsId}">` + +"</div>");
            div.css("width", "100%");
            div.css("height", "100%");
            div.css("background", "white");
            con.append(div);
            this.initResizeOb(div[0]);
        }
        let msgCon = con.find(`#${this.JSONNotLoadedConId}`);
        if (msgCon.length > 0) {
            msgCon[0].parentNode.removeChild(msgCon[0])
        }
    }

    initResizeOb = (div) => {
        this._resizeObserver = new ResizeObserver(entries => {
            for (let entry of entries) {
                if (entry.target.id === this.echartsId) { //一开始会resize一下
                    //https://stackoverflow.com/questions/67751039/javascript-resizeobserver-is-triggered-unexpected
                    if (this.firstRenderd) { //https://github.com/apache/echarts/pull/14553
                        this.echartsInst?.resize();
                    } else {
                        this.firstRenderd = true;
                    }
                }
            }
        });
        this._resizeObserver.observe(div);
    }

    appendJSONDataNotLoadedMessage(jsonDatasourceName) {
        const container = this.getContainer();
        let msgCon = container.find(`#${this.JSONNotLoadedConId}`);
        if (msgCon.length > 0) {
            msgCon[0].parentNode.removeChild(msgCon[0])
        }

        const message = this.getPluginResource("JSON_Not_Found").replace("{0}", jsonDatasourceName);
        container.append($(`<div style="position:absolute;top:0;left:0;" id=${this.JSONNotLoadedConId}>${message}</div>`))
    }
    createContent() {
        this.echartsId = this.ID + 'EchartsCon';
        return undefined;
    }

    setDatas(datas) {
        this.dataDic = {};
        datas.forEach(v => {
            this.dataDic[v.name] = v.data;
        });
    }
    ShowLoading() {//C#method
        this.echartsInst?.showLoading({ text: '' });
    }
    HideLoading() {//C#method
        this.echartsInst?.hideLoading();
    }
    ReloadGraph(reloadKeepJSONData, forceUpdate) {//C#method
        if (forceUpdate) {
            this.echartsInst?.dispose();
            this.echartsInst = undefined;
        }
        this.onPageLoaded(this.pageLoadInfo, reloadKeepJSONData);
    }
    batchSetDataSource(_jsonDataSouce) {
        _jsonDataSouce.forEach(v => {
            this.JSONDic[v.Name] = JSON.parse(v.JSONDemo);
        });
    }
    SetDataSource(key, value) {//C#method
        this.JSONDic[key] = JSON.parse(value);
        this.initEchartsContainer();
        this.computeGraphData();
    }
    computeGraphData = async () => {
        const code = this.config.jsCode;
        if (!code) {
            return;
        }
        try {
            if (this.datInst) {
                this.datInst.destroy();
                this.datInst = undefined;
            }
            const fn = new Function(`return ${code.trim()}`);
            this.initEcharts();
            const res = await fn()({
                Context: this.dataDic,
                JSONContext: this.overrideGetMethod(this.JSONDic),
                ImageContext: this.IconDic,
                echarts,
                myChart: this.echartsInst,
                dat,
                Forguncy,
                d3: d3,
                setInterval: this.wrapedSetInterval,
                setTimeout: this.wrapedSettimeOut,
                ForguncyEchartsHelper,
                PublicResource: new Proxy({}, {
                    get(target, property) {
                        return this.getApplicationResource("~" + property);
                    }
                })
            });
            this.datInst = res.datGUI;
            this.echartsOption = res.option;
            this.setEchartsOption();
        } catch (err) {
            if (err.message.indexOf(JSON_DATA_SOURCE_NOT_INITED) === 0) {
                const msg = err.message.substring(JSON_DATA_SOURCE_NOT_INITED.length + 1);
                this.appendJSONDataNotLoadedMessage(msg);
                this.echartsInst?.dispose();
                this.echartsInst = undefined;
            }
        }
    }
    initEcharts = () => {
        const { displayMode, graphTheme } = this.config;
        if (!this.echartsInst) {
            this.echartsInst = echarts.init(document.getElementById(this.echartsId), graphTheme, {
                renderer: displayMode,
                locale: Forguncy.RS.Culture == "cn" ? "ZH" : "EN"//"EN" "CN"
            });
            this.attachEventHandle();
        }
    }
    overrideGetMethod = (jsonContext) => {
        const proxyObject = new Proxy(jsonContext, {
            get(target, property, receiver) {
                const value = Reflect.get(target, property, receiver);
                if (value === undefined) {
                    throw new Error([JSON_DATA_SOURCE_NOT_INITED, property].join("|"));
                }
                return value;
            }
        });
        return proxyObject;
    }
    eventHandle = (param) => {
        const command = this.CellElement.CellType.ClickCommand;
        delete param.event;
        const rawData = JSON.stringify(param);
        const str = this.decodeUnicodeString(rawData);
        const data = JSON.parse(str);
        const initPrarm = {};
        initPrarm[command.ParamProperties["name"]] = data.name;
        initPrarm[command.ParamProperties["seriesName"]] = data.seriesName;
        initPrarm[command.ParamProperties["seriesType"]] = data.seriesType;
        initPrarm[command.ParamProperties["value"]] = data.value;
        initPrarm[command.ParamProperties["rawData"]] = rawData;
        this.executeCustomCommandObject(command, initPrarm);
    }
    wrapedSetInterval = (handler, timeout, ...args) => {
        const id = setInterval(handler, timeout, ...args)
        this.intervalMap[id] = id;
        return id;
    }
    wrapedSettimeOut = (handler, timeout, ...args) => {
        const id = setTimeout(handler, timeout, ...args)
        this.timeoutMap[id] = id;
        return id;
    }

    clearAllTimer = () => {
        Object.keys(this.timeoutMap).forEach(v => {
            clearTimeout(parseInt(v));
            delete this.timeoutMap[v];
        });
        Object.keys(this.intervalMap).forEach(v => {
            clearInterval(parseInt(v));
            delete this.intervalMap[v];
        });
    }
    haveCommand = () => {
        const command = this.CellElement.CellType.ClickCommand;
        if (command) {
            const validCommand = command.Commands.filter(v => !v.Disabled);
            if (validCommand.length > 0) {
                return true;
            }
        }
        return false;
    }
    attachEventHandle() {

        if (this.eventHandleAttached) {
            this.echartsInst?.off('click', this.eventHandle);
            this.eventHandleAttached = false;
        }
        if (this.haveCommand()) {
            this.eventHandleAttached = true;
            this.echartsInst?.on('click', this.eventHandle);
        }
    }

    setEchartsOption() {
        const opt = this.echartsOption;
        if (Object.keys(opt).length === 0) {
            return;
        }
        if (this.isDesignerPreview) {
            // 预览模式下不需要动画，动画会影响绘制速度
            this.echartsOption.animation = false;
        }
        const titleNotSet = !Object.keys(this.echartsOption).find(v => v === 'title');
        if (titleNotSet && this.CellElement.CellType.EChartTitle) {
            const titleText = this.getApplicationResource(this.CellElement.CellType.EChartTitle);
            const newOption = {
                ...this.echartsOption,
                title: {
                    left: 'center',
                    text: titleText
                }
            };
            this.echartsInst?.setOption(newOption);
        } else {
            this.echartsInst?.setOption(this.echartsOption);
        }
    }

    decodeUnicodeString(unicodeString) {
        return unicodeString.replaceAll("\\u0000", " ");
    }
    onBindingTableChanged(tableName) {
        const { DataSources } = this.CellElement.CellType;
        const changedDataSouces = DataSources.find(v => v.BindingTableOptions.TableName === tableName);
        if (changedDataSouces) {
            this.fetchDataSourceValue(changedDataSouces.Name, changedDataSouces.BindingTableOptions).then(data => {
                this.dataDic[data.name] = data.data;
                this.initEchartsContainer();
                this.computeGraphData();
            })
        }
    }
    destroy() {
        this.echartsInst?.dispose();
        this.datInst?.destroy();
        this.clearAllTimer();
        this._resizeObserver?.disconnect();
    }
    async fetchDataSourceValue(name, bindingTableOptions) {
        return new Promise(resolve => {
            this.getBindingDataSourceValue(bindingTableOptions, null, async (data) => {
                resolve({ name, data });
            });
        });
    }
}
Forguncy.Plugin.CellTypeHelper.registerCellType("EchartsCustomCellType.EchartsCustomCellTypeCellType, EchartsCustomCellType", EchartsCustomCellTypeCellType);


function convertBase64ToFileURL(base64String) {
    const byteCharacters = atob(base64String);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
        const slice = byteCharacters.slice(offset, offset + 512);
        const byteNumbers = new Array(slice.length);

        for (let i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }

        const byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
    }

    const blob = new Blob(byteArrays, {});
    const fileURL = URL.createObjectURL(blob);

    return fileURL;
} class ForguncyEchartsHelper {
    static splitDataSource(objList, option) {
        const res = {}
        objList.forEach((obj, index) => {
            Object.keys(obj).forEach(key => {
                const item = option?.formatter?.[key]
                    ? option?.formatter?.[key](obj[key], index)
                    : obj[key]
                if (!res[key]) {
                    res[key] = [item]
                } else {
                    if (option?.unique?.[key]) {
                        if (res[key]?.includes(item)) {
                            //
                        } else {
                            res[key]?.push(item)
                        }
                    } else {
                        res[key]?.push(item)
                    }
                }
            })
        })
        return res
    }
    static groupBy(objList, option) {
        const res = {}
        objList.forEach((v, index) => {
            const item = option.formatter ? option.formatter(v, index) : v
            if (res[v[option.key]] === undefined) {
                res[v[option.key]] = [item]
            } else {
                res[v[option.key]]?.push(item)
            }
        })
        return res
    }
    static toDataSet(objList) {
        const res = []
        if (objList[0]) {
            res.push(Object.keys(objList[0]))
            objList.forEach(v => {
                const temp = []
                Object.keys(v).forEach(key => {
                    temp.push(v[key])
                })
                res.push(temp)
            })
        }
        return res
    }

    static getAttachment(attachment, index = 0) {
        if (attachment) {
            return fetch(getFileDownloadUrl(attachment.split('|')[index]))
        } else {
            return new Promise(res => {
                res(undefined)
            })
        }
    }
    static getUploadImage(src) {
        return getPrefix() + src;
    }
}
function getFileDownloadUrl(params) {
    return Forguncy.Helper.SpecialPath.getFileDownloadUrl(params)
}
function getPrefix() {
    return Forguncy.Helper.SpecialPath.getUploadImageFolderPathInServer();
}
