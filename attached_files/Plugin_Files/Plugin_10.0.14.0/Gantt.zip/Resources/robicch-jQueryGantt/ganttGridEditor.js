/*
 Copyright (c) 2012-2018 Open Lab
 Written by Roberto Bicchierai and Silvia Chelazzi http://roberto.open-lab.com
 Permission is hereby granted, free of charge, to any person obtaining
 a copy of this software and associated documentation files (the
 "Software"), to deal in the Software without restriction, including
 without limitation the rights to use, copy, modify, merge, publish,
 distribute, sublicense, and/or sell copies of the Software, and to
 permit persons to whom the Software is furnished to do so, subject to
 the following conditions:

 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
function GridEditor(master) {
    this.master = master; // is the a GantEditor instance

    /* <Modify the source code> */
    /*
     * configuration column
     * 
     * <Origin code>
     * var editorTabel = $.JST.createFromTemplate({}, "TASKSEDITHEAD");
     * </Origin code>
     */
    var editorTabel = this.createEditorTabel();
    /* </Modify the source code> */
    if (!master.permissions.canSeeDep)
        editorTabel.find(".pluginGantt_requireCanSeeDep").hide();

    this.gridified = $.gridify(editorTabel);
    this.element = this.gridified.find(".pluginGantt_gdfTable").eq(1);

    this.minAllowedDate = new Date(new Date().getTime() - 3600000 * 24 * 365 * 20).format();
    this.maxAllowedDate = new Date(new Date().getTime() + 3600000 * 24 * 365 * 30).format();
}

GridEditor.prototype.createTaskBody = function (params) {
    /*
     * start es6 -> es5
     * 
     * const { taskSetColInfo, OrderCol, CommandCol, StatusCol, CodeCol, NameCol, StartIsMilestoneCol, ActualStartCol, StartCol, ActualEndCol, EndCol, EndIsMilestoneCol, ActualDurationCol, DurationCol, ProgressCol, DependsCol, AssigsCol, DescriptionCol, WhiteSpaceCol } = params;
     */
    var _params = params;
	var	taskSetColInfo = _params.taskSetColInfo;
	var	OrderCol = _params.OrderCol;
	var	CommandCol = _params.CommandCol;
	var	StatusCol = _params.StatusCol;
	var	CodeCol = _params.CodeCol;
	var	NameCol = _params.NameCol;
	var	StartIsMilestoneCol = _params.StartIsMilestoneCol;
	var	ActualStartCol = _params.ActualStartCol;
	var	StartCol = _params.StartCol;
	var	ActualEndCol = _params.ActualEndCol;
	var	EndCol = _params.EndCol;
	var	EndIsMilestoneCol = _params.EndIsMilestoneCol;
	var	ActualDurationCol = _params.ActualDurationCol;
	var	DurationCol = _params.DurationCol;
	var	ProgressCol = _params.ProgressCol;
	var	DependsCol = _params.DependsCol;
	var	AssigsCol = _params.AssigsCol;
	var	DescriptionCol = _params.DescriptionCol;
	var	WhiteSpaceCol = _params.WhiteSpaceCol;
    /* end es6 -> es5 */

    return OrderCol +
    (this.master.hasSetCommands ? CommandCol : '') +
    (taskSetColInfo.hasOwnProperty('StatusCol') ? StatusCol : '') +
    (taskSetColInfo.hasOwnProperty('CodeCol') ? CodeCol : '') +
    NameCol +
    DurationCol +
    StartCol +
    EndCol +
    // now only show one milestone, endIsMilestone === isMilestone
    // (taskSetColInfo.hasOwnProperty('StartIsMilestoneCol') ? StartIsMilestoneCol : '') +
    (taskSetColInfo.hasOwnProperty('EndIsMilestoneCol') ? EndIsMilestoneCol : '') +
    DependsCol +
    (this.master.hasActualSetting ? ActualDurationCol : '') +
    (this.master.hasActualSetting ? ActualStartCol : '') +
    (this.master.hasActualSetting ? ActualEndCol : '') +
    (taskSetColInfo.hasOwnProperty('ProgressCol') ? ProgressCol : '') +
    (taskSetColInfo.hasOwnProperty('AssigsCol') ? AssigsCol : '') +
    (taskSetColInfo.hasOwnProperty('DescriptionCol') ? DescriptionCol : '') +
    WhiteSpaceCol;
}

GridEditor.prototype.createEditorTabel = function () {
    const taskSetColInfo = this.master.ganttTaskSetColInfo;
    const lang = this.master.lang.GridEditor.Tabel;

    const editorTableStart = "<table class='pluginGantt_gdfTable' cellspacing='0' cellpadding='0'><thead><tr style='height:40px'>";

    const OrderCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width:35px;'></th>";
    const CommandCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width:35px;'></th>";
    const StatusCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width:60px;' title='" + lang.statusColTitle + "'>" + lang.statusCol + "</th>";
    const CodeCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width:100px;' title='" + lang.codeNameColTitle + "'>" + lang.codeNameCol + "</th>";
    const NameCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width:200px;' title='" + lang.nameColTitle + "'>" + lang.nameCol + "</th>";
    const StartIsMilestoneCol = "<th class='pluginGantt_gdfColHeader' align='center' style='width:30px;' title='" + lang.startMilestoneColTitle + "'><span class='pluginGantt_teamworkIcon' style='font-size: 8px;'>^</span></th>";
    const ActualStartCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width:100px;' title='" + lang.actualStartColTitle + "'>" + lang.actualStartCol + "</th>";
    const StartCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width:100px;' title='" + lang.startColTitle + "'>" + lang.startCol + "</th>";
    const ActualEndCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width:100px;' title='" + lang.actualEndColTitle + "'>" + lang.actualEndCol + "</th>";
    const EndCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width:100px;' title='" + lang.endColTitle + "'>" + lang.endCol + "</th>";
    // now only show one milestone, endIsMilestone === isMilestone
    // const EndIsMilestoneCol = "<th class='pluginGantt_gdfColHeader' align='center' style='width:30px;' title='" + lang.endMilestoneColTitle + "'><span class='pluginGantt_teamworkIcon' style='font-size: 8px;'>^</span></th>";
    const EndIsMilestoneCol = "<th class='pluginGantt_gdfColHeader' align='center' style='width:35px;' title='" + lang.milestoneColTitle + "'><span class='pluginGantt_teamworkIcon' style='font-size: 12px;'>^</span></th>";
    const ActualDurationCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width:80px;' title='" + lang.actualDurationColTitle + "'>" + lang.actualDurationCol + "</th>";
    const DurationCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width:60px;' title='" + lang.durationColTitle + "'>" + lang.durationCol + "</th>";
    const ProgressCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width:50px;' title='" + lang.progressColTitle + "'>" + lang.progressCol + "</th>";
    const DependsCol = "<th class=pluginGantt_gdfColHeader pluginGanntt_gdfResizable pluginGantt_requireCanSeeDep' style='width:80px;' title='" + lang.dependsColTitle + "'>" + lang.dependsCol + "</th>";
    const AssigsCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width: 120px;' title='" + lang.assigsColTitle + "'>" + lang.assigsCol + "</th>";
    const DescriptionCol = "<th class='pluginGantt_gdfColHeader pluginGanntt_gdfResizable' style='width: 300px;' title='" + lang.descriptionColTitle + "'>" + lang.descriptionCol + "</th>";
    const WhiteSpaceCol = "<th class='pluginGantt_gdfColHeader'></th>";
        
    var params = { taskSetColInfo: taskSetColInfo, OrderCol: OrderCol, CommandCol: CommandCol, StatusCol: StatusCol, CodeCol: CodeCol, NameCol: NameCol, StartIsMilestoneCol: StartIsMilestoneCol, ActualStartCol: ActualStartCol, StartCol: StartCol, ActualEndCol: ActualEndCol, EndCol: EndCol, EndIsMilestoneCol: EndIsMilestoneCol, ActualDurationCol: ActualDurationCol, DurationCol: DurationCol, ProgressCol: ProgressCol, DependsCol: DependsCol, AssigsCol: AssigsCol, DescriptionCol: DescriptionCol, WhiteSpaceCol: WhiteSpaceCol };
    const editorTableBody = this.createTaskBody(params);
    
    const editorTableEnd = "</tr></thead></table>";

    const editorTable = editorTableStart + editorTableBody + editorTableEnd;

    return $(editorTable);
}

GridEditor.prototype.createTaskRow = function(task) {
    /*
     * start es6 -> es5
     * 
     * const { id, collapsed, level, status, code, name, actualDuration, duration, progress, progressByWorklog, depends, hasExternalDep, description, assigs } = task;
     */
    var _task = task;
    var id = _task.id;
    var collapsed = _task.collapsed;
    var level = _task.level;
    var status = _task.status;
    var code = _task.code;
    var name = _task.name;
    // if actualDuration equal to undefined, it will display undefined first
    var actualDuration = _task.actualDuration || "";
    var duration = _task.duration;
    var progress = _task.progress;
    var progressByWorklog = _task.progressByWorklog;
    var depends = _task.depends;
    var hasExternalDep = _task.hasExternalDep;
    var description = _task.description;
    var assigs = _task.assigs;
    /* end es6 -> es5 */

    const taskSetColInfo = this.master.ganttTaskSetColInfo;
    const lang = this.master.lang.GridEditor.TaskRow;
    const langStatus = this.master.lang.GridEditor.Status;

    /*
     * start es6 -> es5
     * 
     * const taskRowStart = `<tr taskId="${id}" class="pluginGantt_tid_${id} pluginGantt_taskEditRow ${task.isParent() ? 'pluginGantt_isParent' : ''} ${collapsed ? 'pluginGantt_collapsed' : ''}" ishide="" level="${level}">`;
     * 
     * const OrderCol = `<th class="pluginGantt_gdfCell" align="center" style="cursor:pointer;"><span class="pluginGantt_taskRowIndex">${task.getRow() + 1}</span></th>`;
     * const CommandCol = `<th class="pluginGantt_gdfCell pluginGantt_gdfCommandCol" align="center"></th>`;
     * const StatusCol = `<td class="pluginGantt_gdfCell pluginGantt_noClip" align="center"><div class="pluginGantt_taskStatus pluginGantt_cvcColorSquare" status="${status}" title="${langStatus[status]}"></div></td>`;
     * const CodeCol = `<td class="pluginGantt_gdfCell"><input type="text" name="code" style="text-align: center" value="${code ? code : ''}" placeholder="${lang.codeNamePlaceholder}"></td>`;
     * const NameCol = `<td class="pluginGantt_gdfCell pluginGantt_indentCell" style="padding-left:${level * 10 + 24}px;"><div class="pluginGantt_exp-controller" align="center"></div><input type="text" name="name" value="${name}" placeholder="${lang.namePlaceholder}"></td>`;
     * const StartIsMilestoneCol = `<td class="pluginGantt_gdfCell" align="center"><input type="checkbox" name="startIsMilestone"></td>`;
     * const ActualStartCol = `<td class="pluginGantt_gdfCell"><input type="text" name="actualstart" style="text-align:center" value="" class="date"></td>`;
     * const StartCol = `<td class="pluginGantt_gdfCell"><input type="text" name="start" style="text-align:center" value="" class="date"></td>`;
     * const EndIsMilestoneCol = `<td class="pluginGantt_gdfCell" align="center"><input type="checkbox" name="endIsMilestone"></td>`;
     * const ActualDurationCol = `<td class="pluginGantt_gdfCell"><input type="text" name="actualduration" style="text-align:center" autocomplete="off" value="${actualDuration}"></td>`;
     * const DurationCol = `<td class="pluginGantt_gdfCell"><input type="text" name="duration" style="text-align:center" autocomplete="off" value="${duration}"></td>`;
     * const ActualEndCol = `<td class="pluginGantt_gdfCell"><input type="text" name="actualend" style="text-align:center" value="" class="date"></td>`;
     * const EndCol = `<td class="pluginGantt_gdfCell"><input type="text" name="end" style="text-align:center" value="" class="date"></td>`;
     * const ProgressCol = `<td class="pluginGantt_gdfCell"><input type="text" name="progress" style="text-align:center" class="validated" entrytype="PERCENTILE" autocomplete="off" value="${progress ? progress : ''}" ${progressByWorklog ? 'readOnly' : ''}></td>`;
     * const DependsCol = `<td class="pluginGantt_gdfCell pluginGantt_requireCanSeeDep"><input type="text" name="depends" style="text-align:center" autocomplete="off" value="${depends}" ${hasExternalDep ? 'readonly':''}></td>`;
     * const AssigsCol = `<td class="pluginGantt_gdfCell"><input type="text" name="assigs" style="text-align:center" value="${assigs}"></td>`;
     * const DescriptionCol = `<td class="pluginGantt_gdfCell"><input type="text" name="description" style="padding-left: 5px" value="${description}"></td>`;
     * const WhiteSpaceCol = `<td class="pluginGantt_gdfCell"></td>`;
     * 
     * const params = { taskSetColInfo, OrderCol, CommandCol, StatusCol, CodeCol, NameCol, StartIsMilestoneCol, ActualStartCol, StartCol, ActualEndCol, EndCol, EndIsMilestoneCol, ActualDurationCol, DurationCol, ProgressCol, DependsCol, AssigsCol, DescriptionCol, WhiteSpaceCol };
     */
    var taskRowStart = "<tr taskId='" + id + "' class='pluginGantt_tid_" + id + " pluginGantt_taskEditRow " + (task.isParent() ? 'pluginGantt_isParent' : '') + " " + (collapsed ? 'pluginGantt_collapsed' : '') + "' ishide='' level='" + level + "'>";

    var OrderCol = '<th class="pluginGantt_gdfCell" align="center" style="cursor:pointer;"><span class="pluginGantt_taskRowIndex">' + (task.getRow() + 1) + '</span></th>';
    var CommandCol = '<th class="pluginGantt_gdfCell pluginGantt_gdfCommandCol" align="center"></th>';
    var StatusCol = '<td class="pluginGantt_gdfCell pluginGantt_noClip" align="center"><div class="pluginGantt_taskStatus pluginGantt_cvcColorSquare" status="' + status + '" title="' + langStatus[status] + '"></div></td>';
    var CodeCol = '<td class="pluginGantt_gdfCell"><input type="text" name="code" style="text-align: center" value="' + (code ? code : '') + '" placeholder="' + lang.codeNamePlaceholder + '"></td>';
    var NameCol = '<td class="pluginGantt_gdfCell pluginGantt_indentCell" style="padding-left:' + (level * 10 + 24) + 'px;"><div class="pluginGantt_exp-controller" align="center"></div><input type="text" name="name" value="' + name + '" placeholder="' + lang.namePlaceholder + '"></td>';
    var StartIsMilestoneCol = '<td class="pluginGantt_gdfCell" align="center"><input type="checkbox" name="startIsMilestone"></td>';
    var ActualStartCol = '<td class="pluginGantt_gdfCell"><input type="text" name="actualstart" style="text-align:center" value="" class="date"></td>';
    var StartCol = '<td class="pluginGantt_gdfCell"><input type="text" name="start" style="text-align:center" value="" class="date"></td>';
    var EndIsMilestoneCol = '<td class="pluginGantt_gdfCell" align="center"><input type="checkbox" name="endIsMilestone"></td>';
    var ActualDurationCol = '<td class="pluginGantt_gdfCell"><input type="text" name="actualduration" style="text-align:center" autocomplete="off" value="' + actualDuration + '"></td>';
    var DurationCol = '<td class="pluginGantt_gdfCell"><input type="text" name="duration" style="text-align:center" autocomplete="off" value="' + duration + '"></td>';
    var ActualEndCol = '<td class="pluginGantt_gdfCell"><input type="text" name="actualend" style="text-align:center" value="" class="date"></td>';
    var EndCol = '<td class="pluginGantt_gdfCell"><input type="text" name="end" style="text-align:center" value="" class="date"></td>';
    var ProgressCol = '<td class="pluginGantt_gdfCell"><input type="text" name="progress" style="text-align:center" class="validated" entrytype="PERCENTILE" autocomplete="off" value="' + (progress ? progress : '') + '" ' + (progressByWorklog ? 'readOnly' : '') + '></td>';
    var DependsCol = '<td class="pluginGantt_gdfCell pluginGantt_requireCanSeeDep"><input type="text" name="depends" style="text-align:center" autocomplete="off" value="' + depends + '" ' + (hasExternalDep ? 'readonly' : '') + '></td>';
    var AssigsCol = '<td class="pluginGantt_gdfCell"><input type="text" name="assigs" style="text-align:center" value="' + assigs + '"></td>';
    var DescriptionCol = '<td class="pluginGantt_gdfCell"><input type="text" name="description" style="padding-left: 5px" value="' + description + '"></td>';
    var WhiteSpaceCol = '<td class="pluginGantt_gdfCell"></td>';

    var params = { taskSetColInfo: taskSetColInfo, OrderCol: OrderCol, CommandCol: CommandCol, StatusCol: StatusCol, CodeCol: CodeCol, NameCol: NameCol, StartIsMilestoneCol: StartIsMilestoneCol, ActualStartCol: ActualStartCol, StartCol: StartCol, ActualEndCol: ActualEndCol, EndCol: EndCol, EndIsMilestoneCol: EndIsMilestoneCol, ActualDurationCol: ActualDurationCol, DurationCol: DurationCol, ProgressCol: ProgressCol, DependsCol: DependsCol, AssigsCol: AssigsCol, DescriptionCol: DescriptionCol, WhiteSpaceCol: WhiteSpaceCol };
    /* end es6 -> es5 */
    
    const taskRowBody = this.createTaskBody(params);
    
    const taskRowEnd = "</tr>";

    const taskRow = taskRowStart + taskRowBody + taskRowEnd;
    return $(taskRow);
}

GridEditor.prototype.createTaskEmptyRow = function () {
    const taskSetColInfo = this.master.ganttTaskSetColInfo;

    const taskEmptyRowStart = "<tr class='pluginGantt_taskEditRow pluginGantt_emptyRow' ishide='false'>";

    const OrderCol = "<th class='pluginGantt_gdfCell' style='width:35px;'></th>";
    const CommandCol = "<th class='pluginGantt_gdfCell' style='width:39px;'></th>";
    const StatusCol = "<td class='pluginGantt_gdfCell pluginGantt_noClip'></td>";
    const CodeCol = "<td class='pluginGantt_gdfCell'></td>";
    const NameCol = "<td class='pluginGantt_gdfCell'></td>";
    const StartIsMilestoneCol = "<td class='pluginGantt_gdfCell'></td>";
    const ActualStartCol = "<td class='pluginGantt_gdfCell'></td>";
    const StartCol = "<td class='pluginGantt_gdfCell'></td>";
    const EndIsMilestoneCol = "<td class='pluginGantt_gdfCell'></td>";
    const ActualDurationCol = "<td class='pluginGantt_gdfCell'></td>";
    const DurationCol = "<td class='pluginGantt_gdfCell'></td>";
    const ActualEndCol = "<td class='pluginGantt_gdfCell'></td>";
    const EndCol = "<td class='pluginGantt_gdfCell'></td>";
    const ProgressCol = "<td class='pluginGantt_gdfCell'></td>";
    const DependsCol = "<td class='pluginGantt_gdfCell pluginGantt_requireCanSeeDep'></td>";
    const AssigsCol = "<td class='pluginGantt_gdfCell'></td>";
    const DescriptionCol = "<td class='pluginGantt_gdfCell'></td>";
    const WhiteSpaceCol = "<td class='pluginGantt_gdfCell'></td>";
    
    /*
     * start es6 -> es5
     * 
     * const params = { taskSetColInfo, OrderCol, CommandCol, StatusCol, CodeCol, NameCol, StartIsMilestoneCol, ActualStartCol, StartCol, ActualEndCol, EndCol, EndIsMilestoneCol, ActualDurationCol, DurationCol, ProgressCol, DependsCol, AssigsCol, DescriptionCol, WhiteSpaceCol };
     */
    var params = { taskSetColInfo: taskSetColInfo, OrderCol: OrderCol, CommandCol: CommandCol, StatusCol: StatusCol, CodeCol: CodeCol, NameCol: NameCol, StartIsMilestoneCol: StartIsMilestoneCol, ActualStartCol: ActualStartCol, StartCol: StartCol, ActualEndCol: ActualEndCol, EndCol: EndCol, EndIsMilestoneCol: EndIsMilestoneCol, ActualDurationCol: ActualDurationCol, DurationCol: DurationCol, ProgressCol: ProgressCol, DependsCol: DependsCol, AssigsCol: AssigsCol, DescriptionCol: DescriptionCol, WhiteSpaceCol: WhiteSpaceCol };
    /* end es6 -> es5 */
    
    const taskEmptyRowBody = this.createTaskBody(params);
    
    const taskEmptyRowEnd = "</tr>";

    const taskEmptyRow = taskEmptyRowStart + taskEmptyRowBody + taskEmptyRowEnd;

    return $(taskEmptyRow);
}

GridEditor.prototype.fillEmptyLines = function () {
    //console.debug("fillEmptyLines")
    var factory = new TaskFactory();
    var master = this.master;

    //console.debug("GridEditor.fillEmptyLines");
    var rowsToAdd = master.minRowsInEditor - this.element.find(".pluginGantt_taskEditRow").length;
    var empty = this.element.find(".pluginGantt_emptyRow").length;
    rowsToAdd = Math.max(rowsToAdd, empty > 5 ? 0 : 5 - empty);

    //fill with empty lines
    for (var i = 0; i < rowsToAdd; i++) {
        /* <Modify the source code> */
        /*
         * configuration column
         * 
         * <Origin code>
         * var emptyRow = $.JST.createFromTemplate({}, "TASKEMPTYROW");
         * </Origin code>
         */
        var emptyRow = this.createTaskEmptyRow();
        /* </Modify the source code> */
        if (!master.permissions.canSeeDep)
            emptyRow.find(".pluginGantt_requireCanSeeDep").hide();

        //click on empty row create a task and fill above
        emptyRow.click(function (ev) {
            //console.debug("emptyRow.click")
            var emptyRow = $(this);
            //add on the first empty row only
            if (!master.permissions.canAdd || emptyRow.prevAll(".pluginGantt_emptyRow").length > 0)
                return;

            master.beginTransaction();
            var lastTask;
            var start = new Date().getTime();
            var level = 0;
            if (master.tasks[0]) {
                start = master.tasks[0].start;
                level = master.tasks[0].level + 1;
            }

            //fill all empty previouses
            var cnt = 0;
            emptyRow.prevAll(".pluginGantt_emptyRow").addBack().each(function () {
                cnt++;
                var ch = factory.build("tmp_fk" + new Date().getTime() + "_" + cnt, "", "", level, start, Date.workingPeriodResolution, undefined, undefined);
                var task = master.addTask(ch);
                lastTask = ch;
            });
            master.endTransaction();
            if (lastTask.rowElement) {
                lastTask.rowElement.find("[name=name]").focus();//focus to "name" input
            }
        });
        this.element.append(emptyRow);
    }
};


GridEditor.prototype.addTask = function (task, row, hideIfParentCollapsed) {
    //console.debug("GridEditor.addTask",task,row);
    //var prof = new Profiler("ganttGridEditor.addTask");

    //remove extisting row
    this.element.find(".pluginGantt_tid_" + task.id).remove();

    /* <Modify the source code> */
    /*
     * configuration column
     * 
     * <Origin code>
     * var taskRow = $.JST.createFromTemplate(task, "TASKROW");
     * </Origin code>
     */
    var taskRow = this.createTaskRow(task, "TASKROW");
    /* </Modify the source code> */

    if (!this.master.permissions.canSeeDep)
        taskRow.find(".pluginGantt_requireCanSeeDep").hide();

    if (!this.master.permissions.canSeePopEdit)
        taskRow.find(".edit .pluginGantt_teamworkIcon").hide();

    //save row element on task
    task.rowElement = taskRow;

    this.bindRowEvents(task, taskRow);

    if (typeof (row) != "number") {
        var emptyRow = this.element.find(".pluginGantt_emptyRow:first"); //tries to fill an empty row
        if (emptyRow.length > 0)
            emptyRow.replaceWith(taskRow);
        else
            this.element.append(taskRow);
    } else {
        var tr = this.element.find("tr.pluginGantt_taskEditRow").eq(row);
        if (tr.length > 0) {
            tr.before(taskRow);
        } else {
            this.element.append(taskRow);
        }

    }

    //[expand]
    if (hideIfParentCollapsed) {
        if (task.collapsed) taskRow.addClass('pluginGantt_collapsed');
        var collapsedDescendant = this.master.getCollapsedDescendant();
        /* <Modify the source code> */
        /*
         * <Origin Code>
         * if (collapsedDescendant.indexOf(task) >= 0) taskRow.hide();
         * </Origin Code>
         */
        if (collapsedDescendant.indexOf(task) >= 0) {
            taskRow.hide();
            taskRow.attr("ishide", "true");
        } else {
            taskRow.attr("ishide", "false");
        }
        /* </Modify the source code> */
    }
    //prof.stop();
    return taskRow;
};

GridEditor.prototype.refreshExpandStatus = function (task) {
    //console.debug("refreshExpandStatus",task);
    if (!task) return;
    if (task.isParent()) {
        task.rowElement.addClass("pluginGantt_isParent");
    } else {
        task.rowElement.removeClass("pluginGantt_isParent");
    }


    var par = task.getParent();
    if (par && !par.rowElement.is("pluginGantt_isParent")) {
        par.rowElement.addClass("pluginGantt_isParent");
    }

};

GridEditor.prototype.refreshTaskRow = function (task) {
    //console.debug("refreshTaskRow")
    //var profiler = new Profiler("editorRefreshTaskRow");
    const langStatus = this.master.lang.GridEditor.Status;

    var canWrite = this.master.permissions.canWrite || task.canWrite;

    var row = task.rowElement;

    row.find(".pluginGantt_taskRowIndex").html(task.getRow() + 1);
    /* <Modify the source code> */
    /*
     * add permissions
     * 
     * <Origin Code>
     * row.find(".pluginGantt_indentCell").css("padding-left", task.level * 10 + 18);
     * row.find("[name=name]").val(task.name);
     * row.find("[name=code]").val(task.code);
     * row.find("[status]").attr("status", task.status).attr("title", langStatus[task.status]);
     * 
     * row.find("[name=duration]").val(durationToString(task.duration)).prop("readonly", !canWrite || task.isParent() && task.master.shrinkParent);
     * row.find("[name=progress]").val(task.progress).prop("readonly", !canWrite || task.progressByWorklog == true);
     * row.find("[name=startIsMilestone]").prop("checked", task.startIsMilestone);
     * row.find("[name=start]").val(new Date(task.start).format()).updateOldValue().prop("readonly", !canWrite || task.depends || !(task.canWrite || this.master.permissions.canWrite)); // called on dates only because for other field is called on focus event
     * row.find("[name=endIsMilestone]").prop("checked", task.endIsMilestone);
     * row.find("[name=end]").val(new Date(task.end).format()).prop("readonly", !canWrite || task.isParent() && task.master.shrinkParent).updateOldValue();
     * row.find("[name=depends]").val(task.depends);
     * </Origin code>
     */
    row.find(".pluginGantt_indentCell").css("padding-left", task.level * 10 + 24);
    row.find("[name=name]").val(task.name).prop("readonly", !canWrite);
    row.find("[name=code]").val(task.code).prop("readonly", !canWrite);
    row.find("[status]").attr("status", task.status).attr("title", langStatus[task.status]).prop("readonly", !canWrite);

    row.find("[name=duration]").val(durationToString(task.duration)).prop("readonly", !canWrite || task.isParent() && task.master.shrinkParent);
    row.find("[name=progress]").val(task.progress).prop("readonly", !canWrite || task.progressByWorklog == true);
    row.find("[name=startIsMilestone]").prop("checked", task.startIsMilestone).prop("readonly", !canWrite);
    row.find("[name=start]").val(new Date(task.start).format()).updateOldValue().prop("readonly", !canWrite || !task.canChangeDate()); // called on dates only because for other field is called on focus event
    row.find("[name=endIsMilestone]").prop("checked", task.endIsMilestone).prop("readonly", !canWrite);
    row.find("[name=end]").val(new Date(task.end).format()).prop("readonly", !canWrite || task.isParent() && task.master.shrinkParent).updateOldValue();
    row.find("[name=depends]").val(task.depends).prop("readonly", !canWrite);
    /*
     * modify assigs width code
     * 
     * <Origin code>
     * row.find(".taskAssigs").html(task.getAssigsString());
     * </Origin code>
     */
    row.find("[name=assigs]").val(task.assigs).prop("readonly", !canWrite);
    /*
     * set actual time, set readonly only through 'canWrite' 
     */
    row.find("[name=description]").val(task.description).prop("readonly", !canWrite);
    row.find("[name=actualduration]").val(!!task.actualDuration ? durationToString(task.actualDuration) : "").prop("readonly", !canWrite && task.master.shrinkParent);
    row.find("[name=actualstart]").val(!!task.actualStart ? new Date(task.actualStart).format() : "").updateOldValue().prop("readonly", !canWrite || !(task.canWrite || this.master.permissions.canWrite)); // called on dates only because for other field is called on focus event
    row.find("[name=actualend]").val(!!task.actualEnd ?new Date(task.actualEnd).format() : "").prop("readonly", !canWrite).updateOldValue();
    /*
     * In the beginning, the entire container is hidden,
     * no need to reset the 'ishide' attribute at this time,
     * other times it is triggered by the user's manual click.
     */
    if (!task.master.workSpace.is(":hidden")) {
        row.attr("ishide", task.rowElement.is(":hidden") ? "true" : "false");
    }
    /* </Modify the source code> */
    
    //manage collapsed
    if (task.collapsed)
        row.addClass("pluginGantt_collapsed");
    else
        row.removeClass("pluginGantt_collapsed");


    //Enhancing the function to perform own operations
    this.master.element.trigger('gantt.task.afterupdate.event', task);
    //profiler.stop();
};

GridEditor.prototype.redraw = function () {
    //console.debug("GridEditor.prototype.redraw")
    //var prof = new Profiler("gantt.GridEditor.redraw");
    for (var i = 0; i < this.master.tasks.length; i++) {
        this.refreshTaskRow(this.master.tasks[i]);
    }
    // check if new empty rows are needed
    if (this.master.fillWithEmptyLines)
        this.fillEmptyLines();

    //prof.stop()

};

GridEditor.prototype.reset = function () {
    this.element.find("[taskid]").remove();
};


GridEditor.prototype.bindRowEvents = function (task, taskRow) {
    var self = this;
    //console.debug("bindRowEvents",this,this.master,this.master.permissions.canWrite, task.canWrite);

    //bind row selection
    taskRow.click(function (event) {
        var row = $(this);
        //console.debug("taskRow.click",row.attr("taskid"),event.target)
        //var isSel = row.hasClass("rowSelected");
        row.closest("table").find(".pluginGantt_rowSelected").removeClass("pluginGantt_rowSelected");
        row.addClass("pluginGantt_rowSelected");

        //set current task
        self.master.currentTask = self.master.getTask(row.attr("taskId"));

        //move highlighter
        self.master.gantt.synchHighlight();

        //if offscreen scroll to element
        var top = row.position().top;
        if (top > self.element.parent().height()) {
            row.offsetParent().scrollTop(top - self.element.parent().height() + 100);
        } else if (top <= 40) {
            row.offsetParent().scrollTop(row.offsetParent().scrollTop() - 40 + top);
        }
    });


    if (this.master.permissions.canWrite || task.canWrite) {
        self.bindRowInputEvents(task, taskRow);

    } else { //cannot write: disable input
        taskRow.find("input").prop("readonly", true);
        taskRow.find("input:checkbox,select").prop("disabled", true);
    }

    if (!this.master.permissions.canSeeDep)
        taskRow.find("[name=depends]").attr("readonly", true);

    self.bindRowExpandEvents(task, taskRow);

    /* <Modify the source code> */
    /*
     * click command icon will trigger rowDblClickEvent
     */
    taskRow.find(".pluginGantt_gdfCommandCol").click(function () { self.master.bindTaskRowDblClickEvent(task); });
    /* </Modify the source code> */
    if (this.master.permissions.canSeePopEdit) {
        /* <Modify the source code> */
        /*
         * call custom event
         * 
         * <Origin code>
         * taskRow.find(".edit").click(function () {self.openFullEditor(task, false)});
         * taskRow.dblclick(function (ev) { //open editor only if no text has been selected
         *    if (window.getSelection().toString().trim()=="")
         *    self.openFullEditor(task, $(ev.target).closest(".taskAssigs").size()>0)
         * });
         * </Origin code>
         */
        taskRow.click(function () { self.master.bindTaskRowClickEvent(task); });
        taskRow.dblclick(function () { self.master.bindTaskRowDblClickEvent(task); });
        /* </Modify the source code> */
    }
    //prof.stop();
};

GridEditor.prototype.bindRowExpandEvents = function (task, taskRow) {
    var self = this;
    //expand collapse
    taskRow.find(".pluginGantt_exp-controller").click(function () {
        var el = $(this);
        var taskId = el.closest("[taskid]").attr("taskid");
        var task = self.master.getTask(taskId);
        if (task.collapsed) {
            self.master.expand(task, false);
        } else {
            self.master.collapse(task, false);
        }
    });
};

GridEditor.prototype.bindRowInputEvents = function (task, taskRow) {
    var self = this;

    //bind dateField on dates
    taskRow.find(".date").each(function () {
        var el = $(this);
        el.click(function () {
            var inp = $(this);
            inp.dateField({
                inputField: el,
                minDate: self.minAllowedDate,
                maxDate: self.maxAllowedDate,
                callback: function (d) {
                    $(this).blur();
                }
            });
        });

        el.blur(function (date) {
            var inp = $(this);
            /* <Modify the source code> */
            /*
             * 如果实际开始（结束）时间的值没有修改，还是会进去判断，否则用户必须修改实际结束（开始）或实际工期的值为不同的值，才能重新得出实际开始（结束）时间。
             * If the value of the actual start (end) time is not modified, it will still be judged, otherwise the user must modify the actual end (start) or the actual duration value to a different value to get the actual start (end) time again.
             * 
             * <Origin code>
             * if (inp.isValueChanged()) {
             * </Origin code>
             */
            var inpFieldName = inp.prop("name");
            if (inp.isValueChanged() || inpFieldName === "actualstart" || inpFieldName === "actualend") {
            /* <Modify the source code> */
                if (!Date.isValid(inp.val())) {
                    /* <Modify the source code> */
                    /*
                     * Actual dates can be set to empty
                     */
                    if (!inp.val()) {
                        // actual date
                        if (inpFieldName === "actualstart" || inpFieldName === "actualend") {
                            var row = inp.closest("tr");
                            var taskId = row.attr("taskId");
                            var task = self.master.getTask(taskId);
                            if (inpFieldName === "actualstart") {
                                task["actualStart"] = undefined;
                            } else if (inpFieldName === "actualend") {
                                task["actualEnd"] = undefined;
                            }
                            self.master.gantt.redraw();
                            return;
                        }
                    }
                    /* </Modify the source code> */
                    alert(self.master.lang.Error["INVALID_DATE_FORMAT"]);
                    inp.val(inp.getOldValue());

                } else {
                    var row = inp.closest("tr");
                    var taskId = row.attr("taskId");
                    var task = self.master.getTask(taskId);

                    var leavingField = inp.prop("name");
                    /* <Modify the source code> */
                    /*
                     * DOMException: Failed to execute 'querySelectorAll' on 'Document'
                     * 
                     * <Origin Code>
                     * var dates = resynchDates(inp, row.find("[name=start]"), row.find("[name=startIsMilestone]"), row.find("[name=duration]"), row.find("[name=end]"), row.find("[name=endIsMilestone]"));
                     * //console.debug("resynchDates",new Date(dates.start), new Date(dates.end),dates.duration)
                     * //update task from editor
                     * self.master.beginTransaction();
                     * self.master.changeTaskDates(task, dates.start, dates.end);
                     * self.master.endTransaction();
                     * inp.updateOldValue(); //in order to avoid multiple call if nothing changed
                     * </Origin Code>
                     */
                    self.master.beginTransaction();
                    if (leavingField === "start" || leavingField === "end") {
                        var dates = resynchDates(inp, row.find("[name=start]"), row.find("[name=startIsMilestone]"), row.find("[name=duration]"), row.find("[name=end]"), row.find("[name=endIsMilestone]"));
                        if (dates) {
                            self.master.changeTaskDates(task, dates.start, dates.end);
                        }
                    } else if (leavingField === "actualstart") {
                        task["actualStart"] = Date.parseString(inp.val()).setHours(0, 0, 0, 0);
                    } else if (leavingField === "actualend") {
                        task["actualEnd"] = Date.parseString(inp.val()).setHours(23, 59, 59, 999);
                    }
                    /* </Modify the source code> */

                    self.master.endTransaction();
                    inp.updateOldValue(); //in order to avoid multiple call if nothing changed
                }
            }
        });
    });


    //milestones checkbox
    taskRow.find(":checkbox").click(function () {
        var el = $(this);
        var row = el.closest("tr");
        var taskId = row.attr("taskId");

        var task = self.master.getTask(taskId);

        //update task from editor
        var field = el.prop("name");

        if (field == "startIsMilestone" || field == "endIsMilestone") {
            self.master.beginTransaction();
            //milestones
            task[field] = el.prop("checked");
            resynchDates(el, row.find("[name=start]"), row.find("[name=startIsMilestone]"), row.find("[name=duration]"), row.find("[name=end]"), row.find("[name=endIsMilestone]"));
            self.master.endTransaction();
        }

    });


    //binding on blur for task update (date exluded as click on calendar blur and then focus, so will always return false, its called refreshing the task row)
    /* <Modify the source code> */
    /*
    * DOMException: Failed to execute 'querySelectorAll' on 'Document'
    * 
    * <Origin code>
    * taskRow.find("input:text:not(.date)").focus(function () {
    * </Origin code>
    */
    // taskRow.find("input:text:not(.date)").focus(function () {
    taskRow.find("input[type='text']").not(".date").focus(function () {
        $(this).updateOldValue();
    /* </Modify the source code> */
    }).blur(function (event) {
        var el = $(this);
        var row = el.closest("tr");
        var taskId = row.attr("taskId");
        var task = self.master.getTask(taskId);
        //update task from editor
        var field = el.prop("name");

        if (el.isValueChanged()) {
            self.master.beginTransaction();

            if (field == "depends") {
                var oldDeps = task.depends;
                task.depends = el.val();

                // update links
                var linkOK = self.master.updateLinks(task);
                if (linkOK) {
                    //synchronize status from superiors states
                    var sups = task.getSuperiors();

                    var oneFailed = false;
                    var oneUndefined = false;
                    var oneActive = false;
                    var oneSuspended = false;
                    var oneWaiting = false;
                    for (var i = 0; i < sups.length; i++) {
                        oneFailed = oneFailed || sups[i].from.status == "STATUS_FAILED";
                        oneUndefined = oneUndefined || sups[i].from.status == "STATUS_UNDEFINED";
                        oneActive = oneActive || sups[i].from.status == "STATUS_ACTIVE";
                        oneSuspended = oneSuspended || sups[i].from.status == "STATUS_SUSPENDED";
                        oneWaiting = oneWaiting || sups[i].from.status == "STATUS_WAITING";
                    }

                    if (oneFailed) {
                        task.changeStatus("STATUS_FAILED")
                    } else if (oneUndefined) {
                        task.changeStatus("STATUS_UNDEFINED")
                    } else if (oneActive) {
                        //task.changeStatus("STATUS_SUSPENDED")
                        task.changeStatus("STATUS_WAITING")
                    } else if (oneSuspended) {
                        task.changeStatus("STATUS_SUSPENDED")
                    } else if (oneWaiting) {
                        task.changeStatus("STATUS_WAITING")
                    } else {
                        task.changeStatus("STATUS_ACTIVE")
                    }

                    self.master.changeTaskDeps(task); //dates recomputation from dependencies
                }

            } else if (field == "duration") {
                /* <Modify the source code> */
                /*
                 * <Origin Code>
                 * var dates = resynchDates(el, row.find("[name=start]"), row.find("[name=startIsMilestone]"), row.find("[name=duration]"), row.find("[name=end]"), row.find("[name=endIsMilestone]"));
                 * self.master.changeTaskDates(task, dates.start, dates.end);
                 * </Origin Code>
                 */
                if (!parseInt(el.val())) {
                    alert(self.master.lang.GridEditor.Error["PLAN_DURATION_VALID"]);
                } else {
                    var dates = resynchDates(el, row.find("[name=start]"), row.find("[name=startIsMilestone]"), row.find("[name=duration]"), row.find("[name=end]"), row.find("[name=endIsMilestone]"));
                    if (dates) {
                        self.master.changeTaskDates(task, dates.start, dates.end);
                    }
                }
                /* </Modify the source code> */
            } else if (field == "name" && el.val() == "") { // remove unfilled task
                self.master.deleteCurrentTask(taskId);


            } else if (field == "progress") {
                task[field] = parseFloat(el.val()) || 0;
                el.val(task[field]);

            /* <Modify the source code> */
            } else if (field == "actualduration") {
                task["actualDuration"] = el.val();
            } else {
                task[field] = el.val();
            }

            self.master.endTransaction();

        } else if (field == "name" && el.val() == "") { // remove unfilled task even if not changed
            if (task.getRow() != 0) {
                self.master.deleteCurrentTask(taskId);

            } else {
                el.oneTime(1, "foc", function () { $(this).focus() }); //
                event.preventDefault();
                //return false;
            }

        }
    });

    //cursor key movement
    taskRow.find("input").keydown(function (event) {
        var theCell = $(this);
        var theTd = theCell.parent();
        var theRow = theTd.parent();
        var col = theTd.prevAll("td").length;

        var ret = true;
        if (!event.ctrlKey) {
            switch (event.keyCode) {
                case 13:
                    if (theCell.is(":text"))
                        theCell.blur();
                    break;

                case 37: //left arrow
                    if (!theCell.is(":text") || (!this.selectionEnd || this.selectionEnd == 0))
                        theTd.prev().find("input").focus();
                    break;
                case 39: //right arrow
                    if (!theCell.is(":text") || (!this.selectionEnd || this.selectionEnd == this.value.length))
                        theTd.next().find("input").focus();
                    break;

                case 38: //up arrow
                    //var prevRow = theRow.prev();
                    var prevRow = theRow.prevAll(":visible:first");
                    var td = prevRow.find("td").eq(col);
                    var inp = td.find("input");

                    if (inp.length > 0)
                        inp.focus();
                    break;
                case 40: //down arrow
                    //var nextRow = theRow.next();
                    var nextRow = theRow.nextAll(":visible:first");
                    var td = nextRow.find("td").eq(col);
                    var inp = td.find("input");
                    if (inp.length > 0)
                        inp.focus();
                    else
                        nextRow.click(); //create a new row
                    break;
                case 36: //home
                    break;
                case 35: //end
                    break;

                case 9: //tab
                case 13: //enter
                    break;
            }
        }
        return ret;

    }).focus(function () {
        $(this).closest("tr").click();
    });


    //change status
    taskRow.find(".pluginGantt_taskStatus").click(function () {
        var el = $(this);
        var tr = el.closest("[taskid]");
        var taskId = tr.attr("taskid");
        var task = self.master.getTask(taskId);

        /* <Modify the source code> */
        /*
         * ${write message}
         * 
         * <Origin code>
         * var changer = $.JST.createFromTemplate({}, "CHANGE_STATUS");
         * changer.find("[status=" + task.status + "]").addClass("selected");
         * </Origin code>
         */
        var changer = self.createChangeStatus();
        /* </Modify the source code> */
        changer.find(".pluginGantt_taskStatus").click(function (e) {
            e.stopPropagation();
            var newStatus = $(this).attr("status");
            changer.remove();
            self.master.beginTransaction();
            task.changeStatus(newStatus);
            self.master.endTransaction();
            el.attr("status", task.status);
        });
        /* <Modify the source code> */
        /*
         * <Origin code>
         * el.oneTime(5000, "hideChanger", function () {
         *     changer.remove();
         * });
         * </Origin code>
         */
        changer.mouseleave(function () {
            changer.remove();
        });
        /* </Modify the source code> */
        el.after(changer);
    });

};

/* <Modify the source code> */
/*
 * template
 */
GridEditor.prototype.createChangeStatus = function() {
    const lang = this.master.lang.GridEditor.Status;
    // es6 -> es5
    // const changeStatus = `
    //     <div class="pluginGantt_taskStatusBox">
    //         <div class="pluginGantt_taskStatus pluginGantt_cvcColorSquare" status="STATUS_ACTIVE" title="${lang.STATUS_ACTIVE}"></div>
    //         <div class="pluginGantt_taskStatus pluginGantt_cvcColorSquare" status="STATUS_DONE" title="${lang.STATUS_DONE}"></div>
    //         <div class="pluginGantt_taskStatus pluginGantt_cvcColorSquare" status="STATUS_FAILED" title="${lang.STATUS_FAILED}"></div>
    //         <div class="pluginGantt_taskStatus pluginGantt_cvcColorSquare" status="STATUS_SUSPENDED" title="${lang.STATUS_SUSPENDED}"></div>
    //         <div class="pluginGantt_taskStatus pluginGantt_cvcColorSquare" status="STATUS_WAITING" title="${lang.STATUS_WAITING}"></div>
    //     </div>`;
    var changeStatus = "\n        <div class=\"pluginGantt_taskStatusBox\">\n            <div class=\"pluginGantt_taskStatus pluginGantt_cvcColorSquare\" status=\"STATUS_ACTIVE\" title=\"" + lang.STATUS_ACTIVE + "\"></div>\n            <div class=\"pluginGantt_taskStatus pluginGantt_cvcColorSquare\" status=\"STATUS_DONE\" title=\"" + lang.STATUS_DONE + "\"></div>\n            <div class=\"pluginGantt_taskStatus pluginGantt_cvcColorSquare\" status=\"STATUS_FAILED\" title=\"" + lang.STATUS_FAILED + "\"></div>\n            <div class=\"pluginGantt_taskStatus pluginGantt_cvcColorSquare\" status=\"STATUS_SUSPENDED\" title=\"" + lang.STATUS_SUSPENDED + "\"></div>\n            <div class=\"pluginGantt_taskStatus pluginGantt_cvcColorSquare\" status=\"STATUS_WAITING\" title=\"" + lang.STATUS_WAITING + "\"></div>\n        </div>";
    return $(changeStatus);
}
/* </Modify the source code> */

GridEditor.prototype.openFullEditor = function (task, editOnlyAssig) {
    var self = this;

    if (!self.master.permissions.canSeePopEdit)
        return;

    var taskRow = task.rowElement;

    //task editor in popup
    var taskId = taskRow.attr("taskId");

    //make task editor
    var taskEditor = $.JST.createFromTemplate(task, "TASK_EDITOR");

    //hide task data if editing assig only
    if (editOnlyAssig) {
        taskEditor.find(".pluginGantt_taskData").hide();
        taskEditor.find(".pluginGantt_assigsTableWrapper").height(455);
        taskEditor.prepend("<h1>\"" + task.name + "\"</h1>");
    }

    //got to extended editor
    if (task.isNew() || !self.master.permissions.canSeeFullEdit) {
        taskEditor.find("#taskFullEditor").remove();
    } else {
        taskEditor.bind("openFullEditor.gantt", function () {
            window.location.href = contextPath + "/applications/teamwork/task/taskEditor.jsp?CM=ED&OBJID=" + task.id;
        });
    }


    taskEditor.find("#name").val(task.name);
    taskEditor.find("#description").val(task.description);
    taskEditor.find("#code").val(task.code);
    taskEditor.find("#progress").val(task.progress ? parseFloat(task.progress) : 0).prop("readonly", task.progressByWorklog == true);
    taskEditor.find("#progressByWorklog").prop("checked", task.progressByWorklog);
    taskEditor.find("#status").val(task.status);
    taskEditor.find("#type").val(task.typeId);
    taskEditor.find("#type_txt").val(task.type);
    taskEditor.find("#relevance").val(task.relevance);
    //cvc_redraw(taskEditor.find(".cvcComponent"));


    if (task.startIsMilestone)
        taskEditor.find("#startIsMilestone").prop("checked", true);
    if (task.endIsMilestone)
        taskEditor.find("#endIsMilestone").prop("checked", true);

    taskEditor.find("#duration").val(durationToString(task.duration));
    var startDate = taskEditor.find("#start");
    startDate.val(new Date(task.start).format());
    //start is readonly in case of deps
    if (task.depends || !(this.master.permissions.canWrite || task.canWrite)) {
        startDate.attr("readonly", "true");
    } else {
        startDate.removeAttr("readonly");
    }

    taskEditor.find("#end").val(new Date(task.end).format());

    //make assignments table
    /* <Modify the source code> */
    /*
     * remove id
     * 
     * <Origin code>
     * var assigsTable = taskEditor.find("#assigsTable");
     * </Origin code>
     */
    var assigsTable = taskEditor.find(".pluginGantt_assigsTable");
    /* </Modify the source code> */
    assigsTable.find("[assId]").remove();
    // loop on assignments
    for (var i = 0; i < task.assigs.length; i++) {
        var assig = task.assigs[i];
        var assigRow = $.JST.createFromTemplate({ task: task, assig: assig }, "ASSIGNMENT_ROW");
        assigsTable.append(assigRow);
    }

    taskEditor.find(":input").updateOldValue();

    if (!(self.master.permissions.canWrite || task.canWrite)) {
        taskEditor.find("input,textarea").prop("readOnly", true);
        taskEditor.find("input:checkbox,select").prop("disabled", true);
        /* <Modify the source code> */
        /*
         * remove id
         * 
         * <Origin code>
         * taskEditor.find("#saveButton").remove();
         * </Origin code>
         */
        taskEditor.find(".pluginGantt_saveButton").remove();
        /* </Modify the source code> */
        taskEditor.find(".pluginGantt_button").addClass("disabled");

    } else {

        //bind dateField on dates, duration
        taskEditor.find("#start,#end,#duration").click(function () {
            var input = $(this);
            if (input.is("[entrytype=DATE]")) {
                input.dateField({
                    inputField: input,
                    minDate: self.minAllowedDate,
                    maxDate: self.maxAllowedDate,
                    callback: function (d) { $(this).blur(); }
                });
            }
        }).blur(function () {
            var inp = $(this);
            if (inp.validateField()) {
                resynchDates(inp, taskEditor.find("[name=start]"), taskEditor.find("[name=startIsMilestone]"), taskEditor.find("[name=duration]"), taskEditor.find("[name=end]"), taskEditor.find("[name=endIsMilestone]"));
                //workload computation
                if (typeof (workloadDatesChanged) == "function")
                    workloadDatesChanged();
            }
        });

        taskEditor.find("#startIsMilestone,#endIsMilestone").click(function () {
            var inp = $(this);
            resynchDates(inp, taskEditor.find("[name=start]"), taskEditor.find("[name=startIsMilestone]"), taskEditor.find("[name=duration]"), taskEditor.find("[name=end]"), taskEditor.find("[name=endIsMilestone]"));
        });

        //bind add assignment
        var cnt = 0;
        /* <Modify the source code> */
        /*
         * remove id
         * 
         * <Origin code>
         * taskEditor.find("#addAssig").click(function () {
         * var assigsTable = taskEditor.find("#assigsTable");
         * $("#bwinPopupd").scrollTop(10000);
         * </Origin code>
         */
        taskEditor.find(".pluginGantt_addAssig").click(function () {
            cnt++;
            var assigsTable = taskEditor.find(".pluginGantt_assigsTable");
            var assigRow = $.JST.createFromTemplate({ task: task, assig: { id: "tmp_" + new Date().getTime() + "_" + cnt } }, "ASSIGNMENT_ROW");
            assigsTable.append(assigRow);
            $(".pluginGantt_bwinPopupd").scrollTop(10000);
        }).click();
        /* </Modify the source code> */

        //save task
        taskEditor.bind("saveFullEditor.gantt", function () {
            //console.debug("saveFullEditor");
            var task = self.master.getTask(taskId); // get task again because in case of rollback old task is lost

            self.master.beginTransaction();
            task.name = taskEditor.find("#name").val();
            task.description = taskEditor.find("#description").val();
            task.code = taskEditor.find("#code").val();
            task.progress = parseFloat(taskEditor.find("#progress").val());
            //task.duration = parseInt(taskEditor.find("#duration").val()); //bicch rimosso perchè devono essere ricalcolata dalla start end, altrimenti sbaglia
            task.startIsMilestone = taskEditor.find("#startIsMilestone").is(":checked");
            task.endIsMilestone = taskEditor.find("#endIsMilestone").is(":checked");

            task.type = taskEditor.find("#type_txt").val();
            task.typeId = taskEditor.find("#type").val();
            task.relevance = taskEditor.find("#relevance").val();
            task.progressByWorklog = taskEditor.find("#progressByWorklog").is(":checked");

            //set assignments
            var cnt = 0;
            taskEditor.find("tr[assId]").each(function () {
                var trAss = $(this);
                var assId = trAss.attr("assId");
                var resId = trAss.find("[name=resourceId]").val();
                var resName = trAss.find("[name=resourceId_txt]").val(); // from smartcombo text input part
                var roleId = trAss.find("[name=roleId]").val();
                var effort = millisFromString(trAss.find("[name=effort]").val(), true);

                //check if the selected resource exists in ganttMaster.resources
                var res = self.master.getOrCreateResource(resId, resName);

                //if resource is not found nor created
                if (!res)
                    return;

                //check if an existing assig has been deleted and re-created with the same values
                var found = false;
                for (var i = 0; i < task.assigs.length; i++) {
                    var ass = task.assigs[i];

                    if (assId == ass.id) {
                        ass.effort = effort;
                        ass.roleId = roleId;
                        ass.resourceId = res.id;
                        ass.touched = true;
                        found = true;
                        break;

                    } else if (roleId == ass.roleId && res.id == ass.resourceId) {
                        ass.effort = effort;
                        ass.touched = true;
                        found = true;
                        break;

                    }
                }

                if (!found && resId && roleId) { //insert
                    cnt++;
                    var ass = task.createAssignment("tmp_" + new Date().getTime() + "_" + cnt, resId, roleId, effort);
                    ass.touched = true;
                }

            });

            //remove untouched assigs
            task.assigs = task.assigs.filter(function (ass) {
                var ret = ass.touched;
                delete ass.touched;
                return ret;
            });

            //change dates
            task.setPeriod(Date.parseString(taskEditor.find("#start").val()).getTime(), Date.parseString(taskEditor.find("#end").val()).getTime() + (3600000 * 22));

            //change status
            task.changeStatus(taskEditor.find("#status").val());

            if (self.master.endTransaction()) {
                taskEditor.find(":input").updateOldValue();
                closeBlackPopup();
            }

        });
    }

    taskEditor.attr("alertonchange", "true");
    var ndo = createModalPopup(800, 450).append(taskEditor);//.append("<div style='height:800px; background-color:red;'></div>")

    //workload computation
    if (typeof (workloadDatesChanged) == "function")
        workloadDatesChanged();



};
