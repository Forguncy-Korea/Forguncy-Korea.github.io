var SelectionPanel;
(function (SelectionPanel) {
    var SPanelModel = (function () {
        function SPanelModel() {
            this.selections = [];
            this.equality = new RowDataEquality();
        }
        SPanelModel.prototype.modify = function (selections) {
            this.sortSelections(selections);
            this.selections = selections;
            this.onModified && this.onModified();
        };
        SPanelModel.prototype.sortSelections = function (selections) {
            var _this = this;
            selections.forEach(function (v) {
                var index = _this.findIndex(v);
                v.sortIndex = index >= 0 ? index : 100000000;
            });
            selections.sort(function (a, b) { return a.sortIndex - b.sortIndex; });
        };
        SPanelModel.prototype.findIndex = function (rowData) {
            if (rowData) {
                for (var i = 0; i < this.selections.length; i++) {
                    if (this.equality.equals(this.selections[i], rowData)) {
                        return i;
                    }
                }
            }
            return -1;
        };
        return SPanelModel;
    }());
    SelectionPanel.SPanelModel = SPanelModel;
    var SPanelPresenter = (function () {
        function SPanelPresenter(model) {
            var _this = this;
            this.maxLabelLength = 20;
            this.model = model;
            this.model.onModified = function () {
                _this.refresh();
            };
            this.container = this.generateContainer();
        }
        SPanelPresenter.prototype.refresh = function () {
            var _this = this;
            this.container.attr("isbusy", "True");
            this.header = this.generateHeader();
            this.container.empty();
            this.container.append(this.header);
            this.model.selections.forEach(function (item) {
                _this.container.append(_this.generateLabel(item));
            });
            this.container.attr("isbusy", "");
        };
        SPanelPresenter.prototype.generateContainer = function () {
            return $("<div></div>").addClass("SPanel-container").attr("isbusy", "True");
        };
        SPanelPresenter.prototype.setRootStyle = function (root) {
            root.addClass("SPanel-root");
        };
        SPanelPresenter.prototype.generateHeader = function () {
            return $("<div></div>").addClass("SPanel-header").text(this.getHeaderHandler());
        };
        SPanelPresenter.prototype.generateLabel = function (rowData) {
            var _this = this;
            var value = rowData.displayValues[this.getDisplayColumnIndexHandler()];
            var text = (value !== null && value !== undefined) ? this.sliceString(value.toString(), this.maxLabelLength) : "";
            var span = $("<span></span>").text(text);
            var label = $("<div></div>").addClass("SPanel-label").append(span);
            label.mouseenter(function () {
                if (_this.getIsShowTooltipHandler()) {
                    label.attr("title", (value !== null && value !== undefined) ? value : "");
                }
            });
            var removeButton = $("<span>&#215;</span>").addClass("SPanel-label-remove");
            removeButton.click(function () {
                _this.container.attr("isbusy", "True");
                _this.removeHandler(rowData);
            });
            return label.append(removeButton);
        };
        SPanelPresenter.prototype.sliceString = function (str, maxLength) {
            if (maxLength === void 0) { maxLength = 0; }
            if (str.length > maxLength) {
                return str.slice(0, maxLength - 1) + "...";
            }
            return str;
        };
        return SPanelPresenter;
    }());
    SelectionPanel.SPanelPresenter = SPanelPresenter;
    var Common = (function () {
        function Common() {
        }
        Common.IsEmpty = function (obj) {
            if (obj === null || obj === "" || obj === undefined) {
                return true;
            }
            return false;
        };
        Common.isQueryEqual = function (query1, query2) {
            if (Common.IsEmpty(query1) || Common.IsEmpty(query2)) {
                return false;
            }
            try {
                for (var i in query1) {
                    if (query1[i] !== query2[i]) {
                        return false;
                    }
                }
            }
            catch (exception) {
                return false;
            }
            return true;
        };
        return Common;
    }());
    var RowDataEquality = (function () {
        function RowDataEquality() {
        }
        RowDataEquality.prototype.equals = function (item1, item2) {
            return this.isIndexEqual(item1, item2) || this.isQueryEqual(item1, item2);
        };
        RowDataEquality.prototype.isQueryEqual = function (item1, item2) {
            return Common.isQueryEqual(item1.Query, item2.Query);
        };
        RowDataEquality.prototype.isIndexEqual = function (item1, item2) {
            return item1.RowIndex >= 0 && item2.RowIndex >= 0 && item1.RowIndex === item2.RowIndex;
        };
        return RowDataEquality;
    }());
})(SelectionPanel || (SelectionPanel = {}));
