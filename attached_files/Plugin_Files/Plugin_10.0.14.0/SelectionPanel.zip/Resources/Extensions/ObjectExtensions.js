var SelectionPanel;
(function (SelectionPanel) {
    var ObjectExtensions = (function () {
        function ObjectExtensions() {
        }
        ObjectExtensions.equals = function (x, y) {
            if (x === y) {
                return true;
            }
            else if (!(x instanceof Object) || !(y instanceof Object)) {
                return false;
            }
            else if (x.constructor !== y.constructor) {
                return false;
            }
            else {
                for (var p in x) {
                    if (!x.hasOwnProperty(p)) {
                        continue;
                    }
                    if (!y.hasOwnProperty(p)) {
                        return false;
                    }
                    if (x[p] === y[p]) {
                        continue;
                    }
                    if (typeof (x[p]) !== 'object') {
                        return false;
                    }
                    if (!this.equals(x[p], y[p])) {
                        return false;
                    }
                }
                for (var p in y) {
                    if (y.hasOwnProperty(p) && !x.hasOwnProperty(p)) {
                        return false;
                    }
                }
                return true;
            }
        };
        return ObjectExtensions;
    }());
    SelectionPanel.ObjectExtensions = ObjectExtensions;
})(SelectionPanel || (SelectionPanel = {}));
